#ifndef TEMPORALDOC_H
#define TEMPORALDOC_H
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/video/background_segm.hpp>

//C
#include <stdio.h>
//C++
#include <sstream>

#include <iostream>
#include <fstream>

#include "utility.h"

using namespace cv;
using namespace std;

#define IN
#define OUT
#define INOUT
#define MOTIF_OK 0
#define MOTIF_ERROR -1

typedef struct _TrackData
{
    Mat pointData;
    unsigned short x1;
    unsigned short y1;
    unsigned short x2;
    unsigned short y2;
    unsigned short time;
    unsigned short Label;
    unsigned int trackIdx;
    ListMgr trkDataMgr;		  	
}TrackData;

typedef struct _TrackDataCentroid
{
    Mat pointCtd;
    Mat cov;
    unsigned short x1;
    unsigned short y1;
    unsigned short x2;
    unsigned short y2;
    unsigned short time;
    unsigned short label;//Only for error check later remove it
    int noOfTrack;
    float maxUD;
    float maxMD;
    float alpha;
    float timestamp;
    float startTime;
	ListMgr trkClusterMgr;		
}TrackDataCentroid;


extern vector <TrackData > gTrkObservations;
extern vector <TrackDataCentroid> gTrkClusters;
extern ofstream logTempDoc;
int showTrkClusterResults(char *pFilepath, Mat&clusterFrame);

int initTrkObservations(unsigned short numObs);
int insertTrkObservation
(
    int x1,
    int y1,
    int x2,
    int y2,
    int time,
    int idx
);
TrackDataCentroid defaultInitedTrkCtd();
void defaultSetTrkObs
(
    int x1,
    int y1,
    int x2,
    int y2,
    int time,
    int index,
    TrackData &obs
);
int initTrkCluster();
int clusterTrkGibbs
(
    int frameNo,
    Mat clusterFrame,
    int gibbsIter
);
int remTrkObsFromCluster
(
    unsigned int pixIdx,
    int frameNo,
    int gibbsIter
);
double probExTrkCluster
(
    unsigned int pixIdx,
    unsigned int pixPos,
    unsigned int *pClusterIdx,
    double *pUD,
    double *pMD
);


double probExTrkCluster
(
    unsigned int pixIdx,
    unsigned int pixPos,
    unsigned int *pClusterIdx,
    double *pUD,
    double *pMD
);
double probNewTrkCluster
(
    unsigned int pixIdx,
    unsigned int pixPos
);

int addTrkObsToCluster
(
    int frameNo,
    unsigned int pixIdx,
    unsigned int clusterIdx,
    Mat clusterFrame
);
int getTrkClusterFromMgr
(

);
int putTrkClusterToMgr
(
    int idx
);

int getTrkCluster
(
    int frameNo
);
int setTrkClusterValue
(
    TrackData &obs,
    int clsIdx,
    int frameNo
);
int initializeTrkObservation(char * trkfilename);
void displayTrkClustersStat();

void displayTrkObservationStat();
int initGradColor();
void setPixelColor(Mat showFrame, int x, int y, int label);
void setHSVPixelColor(Mat &showFrame, int x, int y, int label);
void setHSVPixelUseColorGradient(Mat &showFrame, 
                                        int x,  
                                        int y, 
                                        int time,
                                        int factor);

#endif
