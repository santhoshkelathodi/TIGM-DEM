#ifndef CONFIG_H
#define CONFIG_H


//end of Parameters to be used in Gibbs Sampling

#define MAX_COLORS 64

#define MAX_NUM_OBS 3500

#define OVERLAP 0

#define CONFIGRD_FPS 15

#define CONFIGRD_NO_OF_SEG 50

#define DISP_PIX_COUNT 0

#define INVALID_IDX 0xFFFFFFFF

#define USE_MOG2 0

#define GIBBS_SAMPLING_NO 1


#define LIFELESS_LABELS_DURATION 0


#define RANDOM_SAMPLING 1

#define WITH_BG_ORDER 1

#define BG_LAST_SAMPLING 1

#define BG_FIRST_SAMPLING 0


#define SPIRAL_SAMPLING 0
#define SPIRAL_OUT_SAMPLING 0


#define SET_INIT_CLUSTER 0

#define CLUSTER_JUMP_DIST 10

#define DISP_CLUSTERING_PROCESS 0

#define THRESHOLD_FACTOR 0.4//0.5//virat1

#define MAX_DIR 10

#define MAX_MAG 11

#define MAX_NUM_MOTIFS 150

#define SIGMA_HARDCODE 0

// Only one of these should be enabled
#define UD 1
#define UD_SQUARE 0
#define UD_CUBE 0
#define UD_GAUSSIAN 0
#define MD 0
#define MD_SQUARE 0
#define MD_GAUSSIAN 0
#define MD_MOGSID 0
#define UD_MOGSID 0


#define SIGMA 0

#define NO_BASE_FEAT 4
#define NO_OF_FEATURES 1





//#define DELTA_EXPONENT (-(31 - log(1))) //UD-virat_02 50-1350

#define DELTA_EXPONENT (-(200 - log(1))) //UD-virat_02 50-1350



#define ALPHA (exp(DELTA_EXPONENT))

//#define DELTA_EXPONENT (-(47*47 - log(1200))) //UD Square

#define BETA (47) //MOGSID square


//#define DELTA_EXPONENT (-1000)

#define MIN_PROB_EXP (-DBL_MAX)

#define DBG_PRINT 1

#define NO_OF_SKIP_FRAMES 1

#define LABEL_TO_TRACE 0


#define LABEL_TO_TRACE_1 3//<-28 late
#define LABEL_TO_TRACE_2 30//<-47 early
#define LABEL_TO_TRACE_3 143//<-173
#define LABEL_TO_TRACE_5 179//<-251 late
#define LABEL_TO_TRACE_6 200
#define LABEL_TO_TRACE_4 236//<->252
#define LABEL_TO_TRACE_7 279//<-304 early
#define LABEL_TO_TRACE_8 308//<->319
#define LABEL_TO_TRACE_9 328//<-319,279,429,308


#define REUSE_CLUSTERS 0

#define PAUSE_FRAME 426


#define DISPLAY 1

#define CALC_TIME 1

#define USE_MAP 0

#define USE_MAF 1

#define LATE_DISPLAY 3


//#define MAX_DIST DBL_MAX

#define DISPLAY_OPTICAL_FLOW 1

#define PAUSE_TIME (10)

#define DIPLAY_HEIGHT 180

//Clustering Features to be used
#define NO_SOURCE_FEATURES 2 /*2 or 0*/  
#define NO_DESTINATION_FEATURES 2 /*2 or 0*/  
#define NO_TIME_FEATURES 1 /*1 or 0*/   

#define TOT_FEATURES (NO_DESTINATION_FEATURES + NO_SOURCE_FEATURES + NO_TIME_FEATURES)

//Clustering Features to be used




#endif //MOTIF_CONFIG_H

