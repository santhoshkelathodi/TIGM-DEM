//============================================================================
// Name        : TrackClustering.cpp
// Author      : Santhosh
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
//============================================================================
// Name        : ClusterTracks.cpp
// Author      : Santhosh
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include <fstream>
#include <stdlib.h>

#include "../h/utility.h"
#include "../h/TrackClustering.h"
#include "../h/config.h"


vector <TrackData > gTrkObservations;
vector <TrackDataCentroid> gTrkClusters;

TrackData *gTrkObsData = 0;
ofstream logTempDoc;
double gProbNewTrkCluster = DELTA_EXPONENT;
ListMgr gMotifMgr = {0};
ListMgr gTrkMgr = {0};
int gNumTrkClusterAlloc=0; 
int gNumTrkClusterFreed=0;

int gNxtFreeCltIdx;
unsigned char gradColor[MAX_COLORS][3];

int testColorGradient(Mat&testFrame)
{
    Mat tempMat;
    for (int x = 0; x < 180; x++)
    {
        for (int y = 0; y < testFrame.rows;y++)
        {
             Vec3b& hsv = testFrame.at<Vec3b>(y, x);
             hsv[0] = x;//hue
             hsv[1] = 255;//saturation
             hsv[2] = 255;//
        }
    }
    cvtColor(testFrame,tempMat,CV_HSV2BGR);
    imwrite("gradient.jpg",tempMat);
}

int showTrackUsingId(char *pFile,int motIdx, Mat&clusterFrame)
{
    Mat tempMat;
    std::ifstream fileStream(pFile);
    int x1, y1, x2, y2;

    if(!fileStream.good())
    {
        std::cerr << "Could not open file:"<<pFile << std::endl;
        return -1;
    }
    if (!(fileStream >> x1))
    {
        std::cerr << "Not enough entries in the file."<<pFile << std::endl;
        return -1;
    }
    if (!(fileStream >> y1))
    {
        std::cerr << "Not enough entries in the file."<<pFile<< std::endl;
        return -1;
    }
    std::cout << x1 << ",";
    std::cout << y1 << std::endl;

    setHSVPixelColor(clusterFrame, x1, y1, motIdx);
    cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
    stringstream ss;
    ss <<"cluster"<<motIdx;
    string motString = ss.str();
    imshow(motString, tempMat); // Show our image inside it.
    x2 = x1;
    y2 = y1;
    int col1, col2;
    int time;
    for(time = 0; fileStream >> col1 && fileStream >> col2; time++)
    {
        x2 = col1;
        y2 = col2;
        //std::cout << x2 << ",";
        //std::cout << y2 << std::endl;
        //setPixelColor(clusterFrame,x2,y2,obs.Label);
        setHSVPixelColor(clusterFrame,x2,y2,motIdx);
        cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
        imshow(motString, tempMat); // Show our image inside it.
        waitKey(1);
    
    }
    waitKey(1);
    if(fileStream.fail())
    {
        std::cerr << "End of file."<<pFile<< std::endl;
    }

}

int showTrackUsingIdColorGrad(char *pFile,int motIdx, int timeDur, Mat&clusterFrame)
{
    Mat tempMat;
    std::ifstream fileStream(pFile);
    int x1, y1, x2, y2;

    if(!fileStream.good())
    {
        std::cerr << "Could not open file:"<<pFile << std::endl;
        return -1;
    }
    if (!(fileStream >> x1))
    {
        std::cerr << "Not enough entries in the file."<<pFile << std::endl;
        return -1;
    }
    if (!(fileStream >> y1))
    {
        std::cerr << "Not enough entries in the file."<<pFile<< std::endl;
        return -1;
    }
    std::cout << x1 << ",";
    std::cout << y1 << std::endl;

    setHSVPixelUseColorGradient(clusterFrame, x1, y1, 0, timeDur);
    cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
    stringstream ss;
    ss <<"cluster"<<motIdx;
    string motString = ss.str();
    imshow(motString, tempMat); // Show our image inside it.
    x2 = x1;
    y2 = y1;
    int col1, col2;
    int time;
    for(time = 0; fileStream >> col1 && fileStream >> col2; time++)
    {
        x2 = col1;
        y2 = col2;
        //std::cout << x2 << ",";
        //std::cout << y2 << std::endl;
        //setPixelColor(clusterFrame,x2,y2,obs.Label);
        //setHSVPixelColor(clusterFrame,x2,y2,motIdx);
        setHSVPixelUseColorGradient(clusterFrame,x2,y2,time, timeDur);
        cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
        imshow(motString, tempMat); // Show our image inside it.
        waitKey(1);
    
    }
    //waitKey(1);
    if(fileStream.fail())
    {
        std::cerr << "End of file."<<pFile<< std::endl;
    }

}

int showTrkClusterResultsMotifWise(char *pFilepath, Mat&clusterFrame)
{
    char filename[200];
    sprintf(filename, pFilepath);
    int length = strlen(filename);
    Mat tempMat;
    int count = 0;
    int max = (MAX_NUM_MOTIFS - gMotifMgr.count);
    Data *pData = gMotifMgr.pFirst;
    for (int motIdx = 0; motIdx < max; motIdx++)
    {
        TrackDataCentroid &mot = gTrkClusters.at(motIdx);
        Mat motFrame = clusterFrame.clone();
        Data *pTrkData = mot.trkClusterMgr.pFirst;
        while (pTrkData)
        {
            sprintf(filename + length, "%d.txt", pTrkData->idx);
            TrackData *pObs = &gTrkObsData[pTrkData->idx];
            if (pObs->Label != motIdx)
            {
                cout<<"Some Error:TrackIdx:"<<pTrkData->idx<<" pObs->Label-"<<pObs->Label<<", motIdx-"<<motIdx<<endl;
                //exit(0);
            }                
            if (pObs->trackIdx != pTrkData->idx)
            {
                cout<<"Some Error"<<endl;
                exit(0);
            }
            //showTrackUsingId(filename, motIdx, motFrame);
            showTrackUsingIdColorGrad(filename,motIdx,pObs->time,motFrame);
            pTrkData = pTrkData->pNext;
        }
        stringstream ss;
        ss <<"./STATION/dstCluster"<<motIdx;
        string motString = ss.str();
        cvtColor(motFrame,tempMat,CV_HSV2BGR);
        imwrite(motString+".jpg",tempMat);// it will store the image in name "result.jpg"
        //Data *pData = pData->pNext;
    }
    
    waitKey(0);
}

int showTrkClusterResults(char *pFilepath, Mat&clusterFrame)
{
    char filename[200];
    sprintf(filename, pFilepath);
    int length = strlen(filename);
    Mat tempMat;
    int count = 0;
    Mat endPtFrame = clusterFrame.clone();
    Mat origTrkFrame = clusterFrame.clone();
    cvtColor(endPtFrame,endPtFrame,CV_HSV2BGR);
    cvtColor(origTrkFrame,origTrkFrame,CV_HSV2BGR);
    for (int trkIdx = 1; trkIdx < MAX_NUM_OBS; trkIdx++)
    {
        sprintf(filename + length, "%d.txt", trkIdx);

        std::ifstream fileStream(filename);
        int x1, y1, x2, y2;
        if(!fileStream.good())
        {
            std::cerr << "Could not open file."<<trkIdx << std::endl;
            continue;
        }
        if (!(fileStream >> x1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        if (!(fileStream >> y1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        std::cout << x1 << ",";
        std::cout << y1 << std::endl;

        TrackData &obs = gTrkObservations.at(count);
        //setPixelColor(endPtFrame,x1,y1,2);
        circle(endPtFrame, Point(x1, y1), 0.5, Scalar(255, 0, 0), -1);
        circle(origTrkFrame, Point(x1, y1), 0.5, Scalar(255, 0, 0), -1);
        setHSVPixelColor(clusterFrame,x1,y1,obs.Label);
        cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
        imshow( "clustered", tempMat); // Show our image inside it.
        imshow( "endpt", endPtFrame); // Show our image inside it.
        x2 = x1;
        y2 = y1;
        int col1, col2;
        int time = 0;
        for(time = 0; fileStream >> col1 && fileStream >> col2; time++)
        {
            x2 = col1;
            y2 = col2;
            //std::cout << x2 << ",";
            //std::cout << y2 << std::endl;
            //setPixelColor(clusterFrame,x2,y2,obs.Label);
            circle(origTrkFrame, Point(x2, y2), 0.5, Scalar(255, 0, 0), -1);
            setHSVPixelColor(clusterFrame,x2,y2,obs.Label);
            cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
            imshow( "clustered", tempMat); // Show our image inside it.
            waitKey(1);

        }
        //setPixelColor(endPtFrame,x2,y2,9);
        circle(endPtFrame, Point(x2, y2), 0.5, Scalar(0, 255, 0), -1);
        imshow( "endpt", endPtFrame); // Show our image inside it.        
        imshow( "origTrkFrame", origTrkFrame); // Show our image inside it.     
        count++;
        waitKey(1);
        if(fileStream.fail())
        {
            std::cerr << "End of file."<<trkIdx<< std::endl;
        }
    }
    imwrite("clusters.jpg",tempMat);// it will store the image in name "result.jpg"
    imwrite("endpt.jpg",endPtFrame);// it will store the image in name "result.jpg"
    imwrite("trackOrig.jpg",origTrkFrame);// it will store the image in name "result.jpg"
    waitKey(0);
}

int createTrkObservationFile(char *pFilepath, char* trkfilename, Mat frame)
{
    char filename[200];
    int count = 0;
    if (std::ifstream(trkfilename))
    {
         std::cout<<trkfilename<< ", File already exists" << std::endl;
         return 0;
    }

    std::ofstream fileOutStream;
    fileOutStream.open (trkfilename);
    
    sprintf(filename, pFilepath);
    int length = strlen(filename);
    for (int trkIdx = 0; trkIdx < MAX_NUM_OBS;trkIdx++)
    {
        sprintf(filename + length, "%d.txt", trkIdx);
        
        std::ifstream fileStream(filename);
        int x1, y1, x2, y2;
        if(!fileStream.good())
        {
            std::cerr << "Could not open file."<<trkIdx << std::endl;
            continue;
        }
        if (!(fileStream >> x1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        if (!(fileStream >> y1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        std::cout << x1 << ",";
        std::cout << y1 << std::endl;
        circle(frame, Point(x1, y1), 0.7, Scalar(trkIdx, trkIdx, trkIdx), -1);
        //imshow( "window", frame ); // Show our image inside it.
        x2 = x1;
        y2 = y1;
        int col1, col2;
        int time = 0;
        for(time = 0; fileStream >> col1 && fileStream >> col2; time++)
        {
            x2 = col1;
            y2 = col2;
            //std::cout << x2 << ",";
            //std::cout << y2 << std::endl;
            circle(frame, Point(x2, y2), 0.7, Scalar(trkIdx, trkIdx, trkIdx), -1);
            imshow( "window", frame); // Show our image inside it.
            waitKey(1);

        }
        fileOutStream<<x1<<"\t"<<y1<<"\t"<<x2<<"\t"<<y2<<"\t"<<time<<"\t"<< trkIdx<<endl;

        count++;
        waitKey(1);
        if(fileStream.fail())
        {
            std::cerr << "End of file."<<trkIdx<< std::endl;
        }
    }
    fileOutStream.close();

}

///trackdata/Dataset/MIT/original_trajectory/
int main(){
    double alpha = 0.5; double beta; double input;

    initGradColor();
    initTrkObservations(MAX_NUM_OBS);
    initTrkCluster();

    logTempDoc.open ("logTempDoc.txt");
    logTempDoc<<"Temporal Document Preparation Log."<<endl;

    //VideoCapture cap("../videos/Crowd_PETS09/Crowd_PETS09_5/S3/High_Level/Time_14-31/View_001/frame_%04d.jpg");
    Mat frame = imread("../trackdata/Dataset/STATION/bg.png", CV_LOAD_IMAGE_COLOR);

    //Mat frame = imread("../trackdata/Dataset/MIT/mit_bg.PNG", CV_LOAD_IMAGE_COLOR);
    //Mat frame = imread("../trackdata/Dataset/QMUL/qmul_bg.png", CV_LOAD_IMAGE_COLOR);
    //Mat frame = imread("../trackdata/Dataset/UCF_Crowd/ucf_bg.jpg", CV_LOAD_IMAGE_COLOR);
    //Mat frame = imread("../trackdata/Dataset/IIT/iit_bg.png", CV_LOAD_IMAGE_COLOR);

    if(! frame.data )  // Check for invalid input
    {
        cout<<"Empty image"<<endl;
        return -1;
    }
    // get the video parameters
    //int frameNumbers = (int) cap.get(CV_CAP_PROP_FRAME_COUNT);
    //int fps = (int) cap.get(CV_CAP_PROP_FPS);
    //cap >> frame;
    if (frame.empty())
    {
        cout<<"Empty video"<<endl;
        return -1;
    }
    cout<<"Original height X width = "<<frame.rows<<"X"<<frame.cols<<endl;
    Mat clusterFrame = frame.clone();
    

    Mat frameTrk;
    cvtColor(frame,frameTrk,CV_BGR2HSV);

    //Mat mask;
    //inRange(frameTrk, Scalar(0,0,0), Scalar(100, 255, 255), mask);
    //frameTrk.setTo(Scalar(0,0,0), mask);
    //frameTrk.setTo(Scalar(0,0,0));
    
    //DISPLAY image
    namedWindow( "window", CV_WINDOW_AUTOSIZE ); // Create a window for display.
    imshow( "window", frame ); // Show our image inside it.
    char* trkfilename = "trackobs.txt";
    
    //sprintf(filename, "../trackdata/Dataset/MIT/original_trajectory/%d.txt", trkIdx);
    //sprintf(filename, "../trackdata/Dataset/UCF_Crowd/original_trajectory/%d.txt", trkIdx);
    //sprintf(filename, "../trackdata/Dataset/IIT/original_trajectory/%d.txt", trkIdx);
    //char *pFilepath = "../trackdata/Dataset/QMUL/original_trajectory/";
    //char *pFilepath = "../trackdata/Dataset/UCF_Crowd/custTrajectory/";
    //char *pFilepath = "../trackdata/Dataset/MIT/CustTrajectory/";
    //char *pFilepath = "../trackdata/Dataset/STATION/original_trajectory/";
    
    //char *pFilepath = "../trackdata/Dataset/STATION/new_trajectory/";
    //char *pFilepath = "../trackdata/Dataset/STATION/cust_trajectory/";
    char *pFilepath = "../trackdata/Dataset/STATION/cust_trajectory_400/";
    
    //char *pFilepath = "../trackdata/Dataset/trajectoriesNew/";
    
    createTrkObservationFile(pFilepath, trkfilename, frame);

    initializeTrkObservation(trkfilename);
 
    
    //SAVE image
    imwrite("result.jpg",frame);// it will store the image in name "result.jpg"
    cout<<"Num Obs:"<<gTrkObservations.size()<<endl;

    //displayTrkObservationStat();


    for (int itr = 0; itr < GIBBS_SAMPLING_NO; itr++)
    {
        clusterTrkGibbs(0, frame, itr);
        displayTrkClustersStat();        
        //cv::waitKey();
    }
    //displayTrkObservationStat();
    //displayTrkClustersStat();
    //showTrkClusterResults(pFilepath, frameTrk);
    showTrkClusterResultsMotifWise(pFilepath, frameTrk);
    //testColorGradient(frameTrk);
#if 0

    cout<<"Num Clusters:"<<(MAX_NUM_MOTIFS - gMotifMgr.count)<<endl;

    /// Create Windows
    namedWindow("Linear Blend", 1);
    
    beta = ( 1.0 - alpha );
    Mat dst;
    addWeighted( frameTrk, alpha, frame, beta, 0.0, dst);
    
    imshow( "Linear Blend", dst );
    imwrite("trackblend.jpg",dst);// it will store the image in name "result.jpg"

    waitKey(0);
#endif
    logTempDoc.close();
}

//Initially all the points will be clusters themselves
int initTrkCluster()
{
    initList(&gMotifMgr, MAX_NUM_MOTIFS);   
    for (int i = 0; i < MAX_NUM_MOTIFS; i++)
    {
        TrackDataCentroid ctd = defaultInitedTrkCtd();
        ctd.trkClusterMgr.pDataList = gTrkMgr.pDataList;           
        gTrkClusters.push_back(ctd);
    }
    gNxtFreeCltIdx = -1;

    return 0;
}

int initTrkObservations(unsigned short numObs)
{
    if (!gTrkObsData)
    {
        gTrkObsData = (TrackData *)malloc(numObs*sizeof(TrackData));
        if (!gTrkObsData)
        {
            cout<<"Allocation failed for gTrkObservations"<<endl;
            exit(0);
        }
    }
    
    initList(&gTrkMgr, numObs);  

    return 0;
}
int initializeTrkObservation(char * trkfilename)
{
    int x1;
    int y1;
    int x2;
    int y2;
    int time;
    int trkIdx;
    std::ifstream fileStream(trkfilename);
    if(!fileStream.good())
    {
        std::cerr << "Could not open file:"<<trkfilename << std::endl;
        return -1;
    }  
    while (!fileStream.fail())
    {
        if (!(fileStream >> x1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }
        if (!(fileStream >> y1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }  
        if (!(fileStream >> x2))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }
        if (!(fileStream >> y2))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }   
        if (!(fileStream >> time))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }  
        if (!(fileStream >> trkIdx))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }    
        insertTrkObservation(x1, y1, x2, y2, time, trkIdx);
    }
}
int insertTrkObservation
(
    int x1,
    int y1,
    int x2,
    int y2,
    int time,
    int idx
)
{
    defaultSetTrkObs(x1, y1, x2, y2, time, idx, gTrkObsData[idx]);
    gTrkObservations.push_back(gTrkObsData[idx]);
}
TrackDataCentroid defaultInitedTrkCtd()
{
    TrackDataCentroid ctd = {Mat(1, TOT_FEATURES, CV_64F, Scalar::all(0)),
                            Mat(TOT_FEATURES, TOT_FEATURES, CV_64F, Scalar::all(0)),
                            0, //x1
                            0, //y1
                            0, //x2
                            0, //y2
                            0, // time
                            gTrkClusters.size(), //clusterLabel
                            0, // No of tracks
                            0,//maxUD
                            0,//maxMD
                            ALPHA,//alpha
                            0,
                            0,
                            {0}};
    return ctd;
}

void defaultSetTrkObs(int x1, int y1,int x2, int y2, int time, int index, TrackData &obs)
{
    Mat test = Mat(1, TOT_FEATURES, CV_64F, Scalar::all(0));
    test.copyTo(obs.pointData);
    obs.x1 = x1;
    obs.y1 = y1;
    obs.x2 = x2;
    obs.y2 = y2;
    obs.time = time;
    obs.Label = INVALID_IDX;
    obs.trackIdx = index;
    int i = 0;
#if NO_DESTINATION_FEATURES
    obs.pointData.at<double>(0,i++) = x2;
    obs.pointData.at<double>(0,i++) = y2;
#endif    
#if NO_SOURCE_FEATURES
    obs.pointData.at<double>(0,i++) = x1;
    obs.pointData.at<double>(0,i++) = y1;
#endif 
#if NO_SOURCE_FEATURES
    obs.pointData.at<double>(0,i++) = time;
#endif

    return;
}


int clusterTrkGibbs
(
    int frameNo,
    Mat clusterFrame,
    int gibbsIter
)
{
    double probNewClust;
    double probExClust;
    double uclidDistance;
    double mahanDistance;
    unsigned int clusterIdx;
    unsigned int maxObs = gTrkObservations.size();


    for (int i = 0;  i < maxObs; i++)
    {
        int idx = i;

        TrackData &obs = gTrkObservations.at(idx);
        if (gibbsIter > 0)
        {
            remTrkObsFromCluster(idx, frameNo, gibbsIter);
        }

        probNewClust = probNewTrkCluster(idx, i);
        probExClust = probExTrkCluster(idx, i, &clusterIdx, &uclidDistance, &mahanDistance);
        //logTempDoc<<"Probab of Obs("<<obs.x<<","<<obs.y<<endl<<"), Prob(ExCluster)="<<probExClust<<", Prob(NewCluster)="<<probNewClust<<endl;
        if (probNewClust > probExClust)//Observation going to new cluster
        {
            //clusterIdx = getTrkCluster(frameNo);//get free cluster
            clusterIdx = getTrkClusterFromMgr();
            if (-1 == clusterIdx)
            {
                cout<<"Cluster numbers exeeded the limit"<<endl;
                exit(0);
            }
            setTrkClusterValue(obs, clusterIdx, frameNo);
        }
        else//Observation going to existing cluster
        {
            //logTempDoc<<"distance = "<<distance<<" of obs("<<obs.x<<","<<obs.y<<")to cluster = "<<clusterIdx<<endl;
            //Add obs to existing cluster
            addTrkObsToCluster(frameNo, idx, clusterIdx, clusterFrame);
            TrackDataCentroid &ctd = gTrkClusters.at(clusterIdx);
            if (uclidDistance > ctd.maxUD)
            {
                ctd.maxUD = uclidDistance;
            }
            if (mahanDistance > ctd.maxMD)
            {
                ctd.maxMD = mahanDistance;
            }
        }

        //logTempDoc<<"AfterAssignframeNo:"<<frameNo<<", ObxIdx:"<<idx<<", dir:"<<obs.dir<<", prevDir:"<<obs.prevDir<<", clsLabel:"<<obs.Label<<endl;
    }

}



//Initially all the points will be clusters themselves
int remTrkObsFromCluster(unsigned int pixIdx, int frameNo, int gibbsIter)
{


    TrackData &obs = gTrkObservations.at(pixIdx);
    unsigned int clusterIdx = obs.Label;

    TrackDataCentroid &ctd = gTrkClusters.at(clusterIdx);

#if 0
    if (frameNo > ctd.timestamp)
    {
        ctd.maxMD = 0;
        ctd.maxUD = 0;
    }
#endif
    //Update the parameters of the centroid
    if (ctd.noOfTrack > 1)
    {
        float curNuX1 = ctd.x1;//nu(n)
        float curNuY1 = ctd.y1;//nu(n)
        float curNuTime = ctd.time;//nu(n)
        float curNuX2 = ctd.x2;//nu(n)
        float curNuY2 = ctd.y2;//nu(n)

        ctd.x1 = (ctd.x1*ctd.noOfTrack - obs.x1)/(ctd.noOfTrack - 1);//nu(n)*n/(n-1) - x(n)/(n-1)
        ctd.y1 = (ctd.y1*ctd.noOfTrack - obs.y1)/(ctd.noOfTrack - 1);
        ctd.x2 = (ctd.x2*ctd.noOfTrack - obs.x2)/(ctd.noOfTrack - 1);
        ctd.y2 = (ctd.y2*ctd.noOfTrack - obs.y2)/(ctd.noOfTrack - 1);
        ctd.time = (ctd.time*ctd.noOfTrack - obs.time)/(ctd.noOfTrack - 1);

        int offset = 0;
        //Update the featureMat
#if NO_DESTINATION_FEATURES 
        ctd.pointCtd.at<double>(0,offset++) = ctd.x2;
        ctd.pointCtd.at<double>(0,offset++) = ctd.y2;
#endif
#if NO_SOURCE_FEATURES 
        ctd.pointCtd.at<double>(0,offset++) = ctd.x1;
        ctd.pointCtd.at<double>(0,offset++) = ctd.y1;
#endif
#if NO_TIME_FEATURES        
        ctd.pointCtd.at<double>(0,offset++) = ctd.time;
#endif
        //Calculate variance ignoring cross variance.Considering only diagonal elements
        // var = s(n)/n
        ctd.cov *= ctd.noOfTrack;
        //s(n) = s(n-1) + [x(n) - nu(n-1)]*[x(n) - nu(n)];
        offset = 0;
#if NO_DESTINATION_FEATURES         
        ctd.cov.at<double>(offset, offset) -= (obs.x2 - ctd.x2)*(obs.x2 - curNuX2);
        offset++;
        ctd.cov.at<double>(offset, offset) -= (obs.y2 - ctd.y2)*(obs.y2 - curNuY2);
        offset++;
#endif
#if NO_SOURCE_FEATURES 
        ctd.cov.at<double>(offset, offset) -= (obs.x1 - ctd.x1)*(obs.x1 - curNuX1);
        offset++;
        ctd.cov.at<double>(offset, offset) -= (obs.y1 - ctd.y1)*(obs.y1 - curNuY1);
        offset++;
#endif
#if NO_TIME_FEATURES         
        ctd.cov.at<double>(offset, offset) -= (obs.time - ctd.time)*(obs.time- curNuTime);
#endif

        //ctd.cov.at<float>(2,2) -= (obs.dir- ctd.dir)*(obs.dir - ctd.dir);
        //ctd.cov.at<float>(3,3) -= (obs.mag- ctd.mag)*(obs.mag - ctd.mag);
        ctd.cov /= (ctd.noOfTrack- 1);

    }
    else
    {
        ctd.x1 = obs.x1;//nu(n)*n/(n-1) - x(n)/(n-1)
        ctd.y1 = obs.y1;
        ctd.x2 = obs.x2;
        ctd.y2 = obs.y2;
        ctd.time = obs.time;

        ctd.cov *= ctd.noOfTrack;
        //s(n) = s(n-1) + [x(n) - nu(n-1)]*[x(n) - nu(n)];

        int offset = 0;
        //Update the featureMat

#if NO_DESTINATION_FEATURES         
        ctd.pointCtd.at<double>(0,offset++) = ctd.x2;
        ctd.pointCtd.at<double>(0,offset++) = ctd.y2;
#endif
#if NO_SOURCE_FEATURES         
        ctd.pointCtd.at<double>(0,offset++) = ctd.x1;
        ctd.pointCtd.at<double>(0,offset++) = ctd.y1;
#endif
#if NO_TIME_FEATURES         
        ctd.pointCtd.at<double>(0,offset++) = ctd.time;
#endif


        offset = 0;

#if NO_DESTINATION_FEATURES 
        ctd.cov.at<double>(offset, offset) = 0;
        offset++;
        ctd.cov.at<double>(offset, offset) = 0;
        offset++;
#endif
#if NO_SOURCE_FEATURES         
        ctd.cov.at<double>(offset, offset) = 0;
        offset++;
        ctd.cov.at<double>(offset, offset) = 0;
        offset++;
#endif
#if NO_TIME_FEATURES         
        ctd.cov.at<double>(offset, offset) = 0;
#endif

    }

    ctd.noOfTrack--;

    //Update the parameters of the centroid
    obs.Label = INVALID_IDX;
    //To handle unassign step
    deleteData(&ctd.trkClusterMgr, obs.trackIdx);
    //To handle unassign step
    
    return 0;
}

//Probability of the pixel going to a new cluster
double probNewTrkCluster
(
    unsigned int pixIdx,
    unsigned int pixPos
)
{
    //Need to consider a likelihood function also
    // if no clusters nearby then probably a new cluster needs to be formed
    //double probNewCluster = DELTA /(NUM_OBS - 1 + DELTA);
    return gProbNewTrkCluster;
}


//finding the probability of pixel going to existing cluster
double probExTrkCluster
(
    unsigned int pixIdx,
    unsigned int pixPos,
    unsigned int *pClusterIdx,
    double *pUD,
    double *pMD
)
{
    double minUDist = 0;
    double minMDist = 0;
    double maxProb = MIN_PROB_EXP;
    unsigned int clusterIdx = INVALID_IDX;
    double ctdx;
    double ctdy;
    double regFactor, regFactor1, regFactor2;
    double regFactorMax, regFactor1Max, regFactor2Max;

    TrackData &obs = gTrkObservations.at(pixIdx);

    //Find the distance with each cluster and find the  Max probability Cluster
    unsigned int clSize = gTrkClusters.size();
    if (clSize <= 0)
    {
        *pUD = minUDist;
        *pMD = minMDist;
        *pClusterIdx = clusterIdx;
        return maxProb;
    }
    for (int idx = 0; idx < clSize; idx++)//Skip the background cluster
    {
        TrackDataCentroid &centroid = gTrkClusters.at(idx);

        //No Need to check against Ctd with 0 Observations
        if (centroid.noOfTrack <= 0)
        {
            continue;
        }

        //displayClusterData(centroid);
        double dist = norm(obs.pointData, centroid.pointCtd, NORM_L2);
        //if (dist > 4*SIGMA)
        //{
        //    continue;
        //}

        //float regFactor = (1/dist)*exp(-dist+15)/(1+exp(-dist+15));//*obs.mag);
        //float regFactor = (1/dist)*obs.mag; earlier
        //float regFactor = 1/(sqrt(2*3.14)*SIGMA_HARDCODE)*exp(-dist*dist/(2*SIGMA_HARDCODE*SIGMA_HARDCODE));
        regFactor1 = (-dist*dist/(2*SIGMA*SIGMA));
        Mat expResult(1,1,CV_64F);
        expResult = ((obs.pointData - centroid.pointCtd)*centroid.cov.inv()*(obs.pointData - centroid.pointCtd).t());
        double expData = expResult.at<double>(0,0);
#if UD_CUBE
        regFactor = -dist*dist*dist;
#elif UD_SQUARE
        regFactor = -dist*dist;
#elif UD
        regFactor = -dist;
#elif UD_GAUSSIAN
        regFactor = regFactor1;
#elif MD_SQUARE
        regFactor = -expData;
#elif MD
        regFactor = - sqrt(expData);
#elif MD_GAUSSIAN
        regFactor = -0.5 *expData;
#elif MD_MOGSID
        double exponent = (expData - (BETA*BETA));
        regFactor =  1/(1 + exp(exponent));
#elif UD_MOGSID || MD_MOGSID
        double exponent = (expData - (BETA*BETA));
        regFactor =  1/(1 + exp(exponent));
#else // should take hardcoded value hardcode should be 1 in this case
        regFactor = -0.5 *expData;
#endif


        //float denominator = (2*CV_PI)* sqrt(determinant(centroid.cov));
        //regFactor2 = exp(regFactor)/denominator;
        //regFactor += -log(denominator);
        //displayClusterData(centroid);

        //float currProb = log(centroid.noOfPix)-log(NUM_OBS - 1 + DELTA) + regFactor;//centroid.noOfPix/(NUM_OBS - 1 + DELTA)* regFactor;
        float currProb = log(centroid.noOfTrack) + regFactor;//centroid.noOfPix/(NUM_OBS - 1 + DELTA)* regFactor;
#if MD_MOGSID
        currProb = centroid.noOfPix * regFactor;
#endif
        if (maxProb < currProb)
        {
            minUDist = dist;
            minMDist = sqrt(expData);
            clusterIdx = idx;
            maxProb = currProb;
            regFactorMax = regFactor;
            regFactor1Max = regFactor1;
            regFactor2Max = regFactor2;
        }
    }

    *pClusterIdx = clusterIdx;
    *pUD= minUDist;
    *pMD= minMDist;

    //maxProb = maxProb;//normalise
    //logTempDoc<<"Dist, regFactor2, regFactor1, regFactor:"<<minDist*minDist<<", "<<regFactor2Max<<", "<<regFactor1Max<< ", " <<regFactorMax<<endl;
    //logTempDoc<<"Probab of Obs("<<obs.x<<","<<obs.y<<"), going to cluster:"<<clusterIdx<<"("<<ctdx<<","<<ctdy<<") is = "<<maxProb<<endl;
    //cout<<"Probab of Obs("<<obs.x<<","<<obs.y<<"), going to cluster:"<<clusterIdx<<"("<<ctdx<<","<<ctdy<<") is = "<<maxProb<<endl;

    return maxProb;// normalise
}

int addTrkObsToCluster
(
    int frameNo,
    unsigned int pixIdx,
    unsigned int clusterIdx,
    Mat clusterFrame
)
{
    TrackData &obs = gTrkObservations.at(pixIdx);

    if (obs.Label == clusterIdx)//Already in cluster?
    {
        logTempDoc<<pixIdx<<"th Observation already in Cluster:"<<clusterIdx<<endl;
        return 0;
    }

    TrackDataCentroid &ctd = gTrkClusters.at(clusterIdx);
    //Update Observation label
    obs.Label = clusterIdx;

    //Update the parameters of the centroid
    ctd.noOfTrack++;

    //Update the parameters of the centroid
    float prevNuX1 = ctd.x1;//nu(n-1)
    float prevNuY1 = ctd.y1;//nu(n-1)
    float prevNuTime = ctd.time;//nu(n-1)
    float prevNuX2 = ctd.x2;//nu(n-1)
    float prevNuY2 = ctd.y2;//nu(n-1)

    ctd.x1 = ctd.x1 + (obs.x1 - ctd.x1)/ctd.noOfTrack;    //nu(n) = nu(n-1) + [(x(n)-nu(n-1)]/n
    ctd.y1 = ctd.y1 + (obs.y1 - ctd.y1)/ctd.noOfTrack;
    ctd.x2 = ctd.x2 + (obs.x2 - ctd.x2)/ctd.noOfTrack;
    ctd.y2 = ctd.y2 + (obs.y2 - ctd.y2)/ctd.noOfTrack;
    ctd.time= ctd.time + (obs.time - ctd.time)/ctd.noOfTrack;

    int offset = 0;
    //Update the featureMat
#if NO_DESTINATION_FEATURES     
    ctd.pointCtd.at<double>(0,offset++) = ctd.x2;
    ctd.pointCtd.at<double>(0,offset++) = ctd.y2;
#endif
#if NO_SOURCE_FEATURES 
    ctd.pointCtd.at<double>(0,offset++) = ctd.x1;
    ctd.pointCtd.at<double>(0,offset++) = ctd.y1;
#endif
#if NO_TIME_FEATURES     
    ctd.pointCtd.at<double>(0,offset++) = ctd.time;
#endif


    //s(n) = s(n-1) + [x(n) - nu(n-1)]*[x(n) - nu(n)]; var = s(n)/n
    ctd.cov *= (ctd.noOfTrack - 1);
    offset = 0;
    //Calculate variance ignoring cross variance.Considering only diagonal elements
#if NO_DESTINATION_FEATURES       
    ctd.cov.at<double>(offset, offset) += (obs.x2 - prevNuX2)*(obs.x2 - ctd.x2);
    offset++;
    ctd.cov.at<double>(offset, offset) += (obs.y2 - prevNuY2)*(obs.y2 - ctd.y2);
    offset++;
#endif
#if NO_SOURCE_FEATURES       
    ctd.cov.at<double>(offset, offset) += (obs.x1- prevNuX1)*(obs.x1- ctd.x1);
    offset++;
    ctd.cov.at<double>(offset, offset) += (obs.y1 - prevNuY1)*(obs.y1 - ctd.y1);
    offset++;
#endif
#if NO_TIME_FEATURES       
    ctd.cov.at<double>(offset, offset) += (obs.time- prevNuTime)*(obs.time - ctd.time);
#endif
    ctd.cov /= ctd.noOfTrack;

    ctd.timestamp = frameNo;
    insertData(&ctd.trkClusterMgr, obs.trackIdx);
    
    return 0;
}


int getTrkClusterFromMgr
(

)
{
    int idx;
    idx = getFreeData(&gMotifMgr);
    if (-1 != idx)
    {
        gNumTrkClusterAlloc++;
        int diff = gNumTrkClusterAlloc - gNumTrkClusterFreed;
        if ((diff) != (MAX_NUM_MOTIFS- gMotifMgr.count)) 
        {
            cout<<"Alloc:cluster List manager has issues, gNumTrkClusterAlloc, gNumTrkClusterFreed:"<<gNumTrkClusterAlloc<< ", gNumClusterFreed" <<gNumTrkClusterFreed<<", gClusterMgr.count"<<gTrkMgr.count<<endl;
            exit(0);
        }    
    }
    int count = 0;
    Data *pDataItem = gMotifMgr.pFirst;
    while (pDataItem)
    {
        count++;
        pDataItem = pDataItem->pNext;
    }
    if (count != gMotifMgr.count)
    {
        cout<<"Alloc:count:"<<count<<", gTrkMgr.count"<<gMotifMgr.count<<endl;
        exit(0);
    }

    return idx;    
}

int putTrkClusterToMgr
(
    int idx
)
{
    insertData(&gMotifMgr, idx);
    gNumTrkClusterFreed++;  
    int diff = gNumTrkClusterAlloc - gNumTrkClusterFreed;
    if ((diff) != (MAX_NUM_MOTIFS - gMotifMgr.count))
    {
        cout<<"Alloc:cluster List manager has issues, diff:"<<diff<<", gTrkMgr.count"<<gMotifMgr.count<<endl;
        exit(0);
    }  
    int count = 0;
    Data *pDataItem = gMotifMgr.pFirst;
    while (pDataItem)
    {
        count++;
        pDataItem = pDataItem->pNext;
    }
    if (count != gMotifMgr.count)
    {
        cout<<"Alloc:count:"<<count<<", gMotifMgr.count"<<gMotifMgr.count<<endl;
        exit(0);
    }
    return 0;
}

int getTrkCluster
(
    int frameNo
)
{
    int idx;

    //PixDataCentroid ctd = defaultInitedCtd();
    //Check whether gNxtFreeCltIdx is in use. Do it later. Dont forget.

    for (int count = 0; count < MAX_NUM_MOTIFS; count++)
    {

        gNxtFreeCltIdx = (gNxtFreeCltIdx + 1) % MAX_NUM_MOTIFS;

        TrackDataCentroid &ctd = gTrkClusters.at(gNxtFreeCltIdx);

        return (gNxtFreeCltIdx);
    }

    return -1;
}

int setTrkClusterValue
(
    TrackData &obs,
    int clsIdx,
    int frameNo
)
{
    TrackDataCentroid &ctd = gTrkClusters.at(clsIdx);

    ctd.x1 = obs.x1;
    ctd.y1 = obs.y1;
    ctd.x2 = obs.x2;
    ctd.y2 = obs.y2;
    ctd.time = obs.time;
    ctd.noOfTrack = 1;
    obs.Label = clsIdx;// do it outside?
    ctd.timestamp = frameNo;
    ctd.startTime = frameNo;

    int offset = 0;
    //Initialise Covariance matrix
#if NO_DESTINATION_FEATURES    
    ctd.cov.at<double>(offset,offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0,offset++) = obs.x2;

    ctd.cov.at<double>(offset,offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0,offset++) = obs.y2;
#endif
#if NO_SOURCE_FEATURES  
    ctd.cov.at<double>(offset, offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0,offset++) = obs.x1;
    ctd.cov.at<double>(offset, offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0,offset++) = obs.y1;
#endif
#if NO_TIME_FEATURES  
    ctd.cov.at<double>(offset,offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0, offset++) = obs.time;
#endif    
    insertData(&ctd.trkClusterMgr, obs.trackIdx);

    return 0;
}

void displayTrkObservationStat()
{
    //logTempDoc<<"--------------------------------------frameNo = "<<frameNo<<endl;
    //logTempDoc<<"frame\t"<<"#Cluster\t"<<"#Cluster(withDelay)"<<endl;
    logTempDoc<<"trackId"<<"\t"<<"x1"<<"\t"<<"y1"<<"\t"<<"x2"<<"\t"<<"y2"<<"\t"<<"time"<<"label"<<"\t"<<endl;
    for (int idx = 0; idx < gTrkObservations.size(); idx++)
    {
        TrackData &obs = gTrkObservations.at(idx);

        logTempDoc<<obs.trackIdx<<"\t"<<obs.x1<<"\t"<<obs.y1<<"\t"<<obs.x2<<"\t"<<obs.y2<<"\t"<<obs.time<<"\t"<<obs.Label<<endl;


    }

}

void displayTrkClustersStat()
{
    //logTempDoc<<"--------------------------------------frameNo = "<<frameNo<<endl;
    //logTempDoc<<"frame\t"<<"#Cluster\t"<<"#Cluster(withDelay)"<<endl;
    logTempDoc<<"label"<<"\t"<<"x1"<<"\t"<<"y1"<<"\t"<<"x2"<<"\t"<<"y2"<<"\t"<<"time"<<"\t"<<"#Tracks"<<endl;
    for (int idx = 0; idx < gTrkClusters.size(); idx++)
    {
        TrackDataCentroid &ctd = gTrkClusters.at(idx);
        if (ctd.noOfTrack)
        {
            logTempDoc<<ctd.label<<"\t"<<ctd.x1<<"\t"<<ctd.y1<<"\t"<<ctd.x2<<"\t"<<ctd.y2<<"\t"<<ctd.time<<"\t"<<ctd.noOfTrack<<"\t"<<ctd.trkClusterMgr.count<<endl;
        }

    }

}

int initGradColor()
{
    gradColor[0 ][0] = 229;gradColor[0 ][1] = 0  ;gradColor[0 ][2] = 200;
    gradColor[1 ][0] = 228;gradColor[1 ][1] = 0  ;gradColor[1 ][2] = 218;
    gradColor[2 ][0] = 220;gradColor[2 ][1] = 0  ;gradColor[2 ][2] = 227;
    gradColor[3 ][0] = 202;gradColor[3 ][1] = 0  ;gradColor[3 ][2] = 227;
    gradColor[4 ][0] = 183;gradColor[4 ][1] = 0  ;gradColor[4 ][2] = 226;
    gradColor[5 ][0] = 165;gradColor[5 ][1] = 0  ;gradColor[5 ][2] = 225;
    gradColor[6 ][0] = 148;gradColor[6 ][1] = 0  ;gradColor[6 ][2] = 225;
    gradColor[7 ][0] = 130;gradColor[7 ][1] = 0  ;gradColor[7 ][2] = 224;
    gradColor[8 ][0] = 112;gradColor[8 ][1] = 0  ;gradColor[8 ][2] = 224;
    gradColor[9 ][0] = 94 ;gradColor[9 ][1] = 0  ;gradColor[9 ][2] = 223;
    gradColor[10][0] = 77 ;gradColor[10][1] = 0  ;gradColor[10][2] = 223;
    gradColor[11][0] = 59 ;gradColor[11][1] = 0  ;gradColor[11][2] = 222;
    gradColor[12][0] = 42 ;gradColor[12][1] = 0  ;gradColor[12][2] = 221;
    gradColor[13][0] = 25 ;gradColor[13][1] = 0  ;gradColor[13][2] = 221;
    gradColor[14][0] = 8  ;gradColor[14][1] = 0  ;gradColor[14][2] = 220;
    gradColor[15][0] = 0  ;gradColor[15][1] = 9  ;gradColor[15][2] = 219;
    gradColor[16][0] = 0  ;gradColor[16][1] = 26 ;gradColor[16][2] = 219;
    gradColor[17][0] = 0  ;gradColor[17][1] = 42 ;gradColor[17][2] = 218;
    gradColor[18][0] = 0  ;gradColor[18][1] = 59 ;gradColor[18][2] = 218;
    gradColor[19][0] = 0  ;gradColor[19][1] = 93 ;gradColor[19][2] = 216;
    gradColor[20][0] = 0  ;gradColor[20][1] = 100;gradColor[20][2] = 216;
    gradColor[21][0] = 0  ;gradColor[21][1] = 126;gradColor[21][2] = 215;
    gradColor[22][0] = 0  ;gradColor[22][1] = 142;gradColor[22][2] = 215;
    gradColor[23][0] = 0  ;gradColor[23][1] = 158;gradColor[23][2] = 214;
    gradColor[24][0] = 0  ;gradColor[24][1] = 174;gradColor[24][2] = 213;
    gradColor[25][0] = 0  ;gradColor[25][1] = 190;gradColor[25][2] = 213;
    gradColor[26][0] = 0  ;gradColor[26][1] = 206;gradColor[26][2] = 212;
    gradColor[27][0] = 0  ;gradColor[27][1] = 212;gradColor[27][2] = 201;
    gradColor[28][0] = 0  ;gradColor[28][1] = 211;gradColor[28][2] = 184;
    gradColor[29][0] = 0  ;gradColor[29][1] = 210;gradColor[29][2] = 167;
    gradColor[30][0] = 0  ;gradColor[30][1] = 210;gradColor[30][2] = 150;
    gradColor[31][0] = 0  ;gradColor[31][1] = 210;gradColor[31][2] = 135;
    gradColor[32][0] = 0  ;gradColor[32][1] = 209;gradColor[32][2] = 117;
    gradColor[33][0] = 0  ;gradColor[33][1] = 208;gradColor[33][2] = 101;
    gradColor[34][0] = 0  ;gradColor[34][1] = 207;gradColor[34][2] = 84 ;
    gradColor[35][0] = 0  ;gradColor[35][1] = 207;gradColor[35][2] = 68 ;
    gradColor[36][0] = 0  ;gradColor[36][1] = 206;gradColor[36][2] = 52 ;
    gradColor[37][0] = 0  ;gradColor[37][1] = 206;gradColor[37][2] = 36 ;
    gradColor[38][0] = 0  ;gradColor[38][1] = 205;gradColor[38][2] = 19 ;
    gradColor[39][0] = 0  ;gradColor[39][1] = 204;gradColor[39][2] = 4  ;
    gradColor[40][0] = 11 ;gradColor[40][1] = 204;gradColor[40][2] = 0  ;
    gradColor[41][0] = 27 ;gradColor[41][1] = 203;gradColor[41][2] = 0  ;
    gradColor[42][0] = 43 ;gradColor[42][1] = 203;gradColor[42][2] = 0  ;
    gradColor[43][0] = 58 ;gradColor[43][1] = 202;gradColor[43][2] = 0  ;
    gradColor[44][0] = 74 ;gradColor[44][1] = 201;gradColor[44][2] = 0  ;
    gradColor[45][0] = 89 ;gradColor[45][1] = 201;gradColor[45][2] = 0  ;
    gradColor[46][0] = 105;gradColor[46][1] = 200;gradColor[46][2] = 0  ;
    gradColor[47][0] = 120;gradColor[47][1] = 200;gradColor[47][2] = 0  ;
    gradColor[48][0] = 135;gradColor[48][1] = 199;gradColor[48][2] = 0  ;
    gradColor[49][0] = 150;gradColor[49][1] = 198;gradColor[49][2] = 0  ;
    gradColor[50][0] = 165;gradColor[50][1] = 198;gradColor[50][2] = 0  ;
    gradColor[51][0] = 180;gradColor[51][1] = 197;gradColor[51][2] = 0  ;
    gradColor[52][0] = 194;gradColor[52][1] = 197;gradColor[52][2] = 0  ;
    gradColor[53][0] = 196;gradColor[53][1] = 180;gradColor[53][2] = 0  ;
    gradColor[54][0] = 195;gradColor[54][1] = 167;gradColor[54][2] = 0  ;
    gradColor[55][0] = 195;gradColor[55][1] = 151;gradColor[55][2] = 0  ;
    gradColor[56][0] = 194;gradColor[56][1] = 136;gradColor[56][2] = 0  ;
    gradColor[57][0] = 194;gradColor[57][1] = 120;gradColor[57][2] = 0  ;
    gradColor[58][0] = 193;gradColor[58][1] = 105;gradColor[58][2] = 0  ;
    gradColor[59][0] = 192;gradColor[59][1] = 90 ;gradColor[59][2] = 0  ;
    gradColor[60][0] = 192;gradColor[60][1] = 75 ;gradColor[60][2] = 0  ;
    gradColor[61][0] = 191;gradColor[61][1] = 60 ;gradColor[61][2] = 0  ;
    gradColor[62][0] = 191;gradColor[62][1] = 45 ;gradColor[62][2] = 0  ;
    gradColor[63][0] = 0;gradColor[63][1] = 0 ;gradColor[63][2] = 0  ;//black

   return 0;
}


void setPixelColor(Mat showFrame, int x, int y, int label)
{
    Vec3b color = showFrame.at<Vec3b>(Point(x, y));
    if (label != 0)
    {

        int colorIdx = (label*7)%MAX_COLORS;
        color.val[0] = gradColor[colorIdx][2];//blue
        color.val[1] = gradColor[colorIdx][1];//green
        color.val[2] = gradColor[colorIdx][0];//red

    }
    // set pixel
    showFrame.at<Vec3b>(Point(x, y)) = color;
}
void setHSVPixelUseColorGradient(Mat &showFrame, 
                                        int x,  
                                        int y, 
                                        int time,
                                        int timeDur)
{
     //Vec3b color = showFrame.at<Vec3b>(Point(x, y));
     Vec3b& hsv = showFrame.at<Vec3b>(y, x);

     hsv[0] = ((float)time/(float)timeDur)*180;//hue
     hsv[1] = 255;//saturation
     hsv[2] = 255;//

     //showFrame.at<Vec3b>(x, y) = hsv;
}

void setHSVPixelColor(Mat &showFrame, int x, int y, int label)
{
     //Vec3b color = showFrame.at<Vec3b>(Point(x, y));
     Vec3b& hsv = showFrame.at<Vec3b>(y, x);

     hsv[0] = label*10;//hue
     hsv[1] = 255;
     hsv[2] = 255;

     //showFrame.at<Vec3b>(x, y) = hsv;
}

