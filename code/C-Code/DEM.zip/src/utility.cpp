
//C
#include <stdio.h>
#include <string.h>

#include "../h/utility.h"



int initList(ListMgr *pDataMgr, int maxCount)
{
    pDataMgr->pDataList = (Data *)malloc (maxCount * sizeof (Data));
    if (!pDataMgr->pDataList)
    {
        //cout<<"Init Data Failed"<<endl;
        return -1;
    }
    //memset to null
    memset (pDataMgr->pDataList, 0, maxCount * sizeof (Data));
    for (int i = 0; i < maxCount; i++)
    {
        pDataMgr->pDataList[i].idx = i;
    }
    pDataMgr->count = 0;
    pDataMgr->pFirst = 0;
    pDataMgr->pLast = 0;
    for (int i = 0; i < maxCount; i++)
    {
        insertData(pDataMgr, i);
    }
}
int insertData(ListMgr *pDataMgr, int idx)
{
    if (!pDataMgr->pFirst)
    {
        pDataMgr->pDataList[idx].pPrev = 0;
        pDataMgr->pDataList[idx].pNext = 0;
        pDataMgr->pFirst = &pDataMgr->pDataList[idx];
        pDataMgr->pLast = pDataMgr->pFirst;
    }
    else
    {
        pDataMgr->pDataList[idx].pPrev = pDataMgr->pLast;
        pDataMgr->pDataList[idx].pNext = 0;
        pDataMgr->pLast->pNext = &pDataMgr->pDataList[idx];
        pDataMgr->pLast = &pDataMgr->pDataList[idx];
    }
    pDataMgr->count++;
}
int getFreeData(ListMgr *pDataMgr)
{
    int idx;
    if (!pDataMgr->count)
    {
        return -1;
    }
    idx = pDataMgr->pFirst->idx;   
    deleteData(pDataMgr, idx);
    return idx;
}

int deleteData(ListMgr *pDataMgr, int idx)
{

    //first
    if (pDataMgr->pFirst->idx == idx)
    {
        pDataMgr->pFirst = pDataMgr->pFirst->pNext;    
    }
    //last
    if (pDataMgr->pLast->idx == idx)
    {
        pDataMgr->pLast = pDataMgr->pLast->pPrev;    
    }
    
    //middle
    if (pDataMgr->pDataList[idx].pPrev)
    {
        pDataMgr->pDataList[idx].pPrev->pNext = pDataMgr->pDataList[idx].pNext;
    }
    if (pDataMgr->pDataList[idx].pNext)
    {
        pDataMgr->pDataList[idx].pNext->pPrev = pDataMgr->pDataList[idx].pPrev;
    }


    pDataMgr->pDataList[idx].pNext = 0;
    pDataMgr->pDataList[idx].pPrev = 0;

    pDataMgr->count--;
}
