//============================================================================
// Name        : ClusterTracks.cpp
// Author      : Santhosh
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include <fstream>
#include <stdlib.h>

#include "../h/utility.h"
#include "../h/TrackClustering.h"
#include "../h/config.h"


vector <TrackData > gTrkObservations;
vector <TrackDataCentroid> gTrkClusters;

TrackData *gTrkObsData = 0;
ofstream logTempDoc;
double gProbNewTrkCluster = DELTA_EXPONENT;
ListMgr gMotifMgr = {0};
ListMgr gTrkMgr = {0};
int gNumTrkClusterAlloc=0; 
int gNumTrkClusterFreed=0;

int gNxtFreeCltIdx;

int gDistanceSwitch = 0; //0 for UD and 1 for MD

int testColorGradient(Mat&testFrame)
{
    Mat tempMat;
    for (int x = 0; x < 180; x++)
    {
        for (int y = 0; y < testFrame.rows;y++)
        {
             Vec3b& hsv = testFrame.at<Vec3b>(y, x);
             hsv[0] = x;//hue
             hsv[1] = 255;//saturation
             hsv[2] = 255;//
        }
    }
    cvtColor(testFrame,tempMat,CV_HSV2BGR);
    imwrite("gradient.jpg",tempMat);
}

int showTrackUsingId(char *pFile,int motIdx, Mat&clusterFrame)
{
    Mat tempMat;
    std::ifstream fileStream(pFile);
    int x1, y1, x2, y2;

    if(!fileStream.good())
    {
        std::cerr << "Could not open file:"<<pFile << std::endl;
        return -1;
    }
    if (!(fileStream >> x1))
    {
        std::cerr << "Not enough entries in the file."<<pFile << std::endl;
        return -1;
    }
    if (!(fileStream >> y1))
    {
        std::cerr << "Not enough entries in the file."<<pFile<< std::endl;
        return -1;
    }
    std::cout << x1 << ",";
    std::cout << y1 << std::endl;

    setHSVPixelColor(clusterFrame, x1, y1, motIdx);
    cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
    stringstream ss;
    ss <<"cluster"<<motIdx;
    string motString = ss.str();
    imshow(motString, tempMat); // Show our image inside it.
    x2 = x1;
    y2 = y1;
    int col1, col2;
    int time;
    for(time = 0; fileStream >> col1 && fileStream >> col2; time++)
    {
        x2 = col1;
        y2 = col2;
        //std::cout << x2 << ",";
        //std::cout << y2 << std::endl;
        //setPixelColor(clusterFrame,x2,y2,obs.Label);
        setHSVPixelColor(clusterFrame,x2,y2,motIdx);
        cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
        imshow(motString, tempMat); // Show our image inside it.
        waitKey(1);
    
    }
    waitKey(1);
    if(fileStream.fail())
    {
        std::cerr << "End of file."<<pFile<< std::endl;
    }

}

int showTrackUsingIdColorGrad(char *pFile,int motIdx, int timeDur, Mat&clusterFrame)
{
    Mat tempMat;
    std::ifstream fileStream(pFile);
    int x1, y1, x2, y2, t1, t2;

    if(!fileStream.good())
    {
        //std::cerr << "Could not open file:"<<pFile << std::endl;
        return -1;
    }
    if (!(fileStream >> x1))
    {
        //std::cerr << "Not enough entries in the file."<<pFile << std::endl;
        return -1;
    }
    if (!(fileStream >> y1))
    {
        //std::cerr << "Not enough entries in the file."<<pFile<< std::endl;
        return -1;
    }
    if (!(fileStream >> t1))
    {
        //std::cerr << "Not enough entries in the file."<<pFile<< std::endl;
        return -1;
    }    
    //std::cout << x1 << ",";
    //std::cout << y1 << std::endl;

    setHSVPixelUseColorGradient(clusterFrame, x1, y1, 0, timeDur);
    //cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
    stringstream ss;
    ss <<"cluster"<<motIdx;
    string motString = ss.str();
    //imshow(motString, tempMat); // Show our image inside it.
    x2 = x1;
    y2 = y1;
    int col1, col2, col3;
    int time;
    for(time = 0; fileStream >> col1 && fileStream >> col2 && fileStream >> col3; time++)
    {
        x2 = col1;
        y2 = col2;
        t2 = col3;
        //std::cout << x2 << ",";
        //std::cout << y2 << std::endl;
        //setPixelColor(clusterFrame,x2,y2,obs.Label);
        //setHSVPixelColor(clusterFrame,x2,y2,motIdx);
        setHSVPixelUseColorGradient(clusterFrame,x2,y2,time, timeDur);
        //cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
        //imshow(motString, tempMat); // Show our image inside it.
        //waitKey(1);
    
    }
    //waitKey(1);
    if(fileStream.fail())
    {
        //std::cerr << "End of file."<<pFile<< std::endl;
    }

}

int showTrkClusterResultsMotifWise
(
    char *pFilepath, 
    Mat&clusterFrame,
    int state
)
{
    char filename[200];
    sprintf(filename, pFilepath);
    int length = strlen(filename);
    Mat tempMat;
    int count = 0;
    int max = (MAX_NUM_MOTIFS - gMotifMgr.count);
    Data *pData = gMotifMgr.pFirst;
    for (int motIdx = 0; motIdx < MAX_NUM_MOTIFS; motIdx++)
    {
        TrackDataCentroid &mot = gTrkClusters.at(motIdx);
        if (0 == mot.noOfTrack)
        {
            continue;
        }
        Mat motFrame = clusterFrame.clone();
        Data *pTrkData = mot.trkClusterMgr.pFirst;
        while (pTrkData)
        {
            sprintf(filename + length, "%d.txt", pTrkData->idx);
            TrackData *pObs = &gTrkObsData[pTrkData->idx];
            if (pObs->Label != motIdx)
            {
                //cout<<"Some Error:TrackIdx:"<<pTrkData->idx<<" pObs->Label-"<<pObs->Label<<", motIdx-"<<motIdx<<endl;
                //exit(0);
            }                
            if (pObs->trackIdx != pTrkData->idx)
            {
                //cout<<"Some Error"<<endl;
                exit(0);
            }
            //showTrackUsingId(filename, motIdx, motFrame);
            showTrackUsingIdColorGrad(filename,motIdx,pObs->time,motFrame);
            pTrkData = pTrkData->pNext;
        }
        stringstream ss;
        ss <<"./results/"<<"Cluster"<<motIdx<<"_state_"<<state;
        string motString = ss.str();
        cvtColor(motFrame,tempMat,CV_HSV2BGR);
        imwrite(motString+".jpg",tempMat);// it will store the image in name "result.jpg"
        //Data *pData = pData->pNext;
    }
    
    waitKey(1);
}


int showTrkClusterComparison(char *pFilepath, Mat&clusterFrame)
{
    char filename[200];
    char clustfilename[200];    
    sprintf(filename, pFilepath);
    sprintf(clustfilename, "clustercomp.txt");    
    int length = strlen(filename);
    Mat tempMat1, tempMat2, tempMat3;
    int count = 0;
    Mat frameMine = clusterFrame.clone();
    Mat frameMeanShift = clusterFrame.clone();
    Mat frameDBSCAN = clusterFrame.clone();

    int trkIdx;
    int dtmLabel;
    int meanshiftLabel;
    int dbscanLabel;
    std::ifstream clustfileStream(clustfilename);
    if(!clustfileStream.good())
    {
        std::cerr << "Could not open file."<<trkIdx << std::endl;
        return -1;
    }
    for (int i = 0; i < MAX_NUM_OBS; i++)
    {

        if (!(clustfileStream >> trkIdx))
        {
            std::cerr << "EndOfFile."<< std::endl;
            break;
        }
        if (!(clustfileStream >> dtmLabel))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }   
        if (!(clustfileStream >> meanshiftLabel))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;            
        }  
        if (!(clustfileStream >> dbscanLabel))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;            
        } 
        //cout<<"meanshiftLabel:"<<meanshiftLabel<<endl;
        if (dbscanLabel != 9)
        {
            continue;
        }
        sprintf(filename + length, "%d.txt", trkIdx);

        std::ifstream fileStream(filename);
        int x1, y1, x2, y2;
        if(!fileStream.good())
        {
            std::cerr << "Could not open file."<<trkIdx << std::endl;
            break;
        }
        if (!(fileStream >> x1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        if (!(fileStream >> y1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        std::cout << x1 << ",";
        std::cout << y1 << std::endl;
        #if 0 
        setHSVPixelColor(frameMine,x1,y1,dtmLabel);
        cvtColor(frameMine,tempMat1,CV_HSV2BGR);
        imshow( "DTM", tempMat1); // Show our image inside it.
        
        setHSVPixelColor(frameMeanShift,x1,y1,meanshiftLabel);
        cvtColor(frameMeanShift,tempMat2,CV_HSV2BGR);
        imshow( "Meanshift", tempMat2); // Show our image inside it.
        
        #endif 
        setHSVPixelColor(frameDBSCAN,x1,y1,dbscanLabel);
        cvtColor(frameDBSCAN,tempMat3,CV_HSV2BGR);
        imshow( "DBSCAN", tempMat3); // Show our image inside it.        
        
        x2 = x1;
        y2 = y1;
        int col1, col2;
        int time = 0;
        for(time = 0; fileStream >> col1 && fileStream >> col2; time++)
        {
            x2 = col1;
            y2 = col2;
            #if 0
            setHSVPixelColor(frameMine,x2,y2,dtmLabel);
            cvtColor(frameMine,tempMat1,CV_HSV2BGR);
            imshow( "DTM", tempMat1); // Show our image inside it.
            
            setHSVPixelColor(frameMeanShift,x2,y2,meanshiftLabel);
            cvtColor(frameMeanShift,tempMat2,CV_HSV2BGR);
            imshow( "Meanshift", tempMat2); // Show our image inside it.
            #endif
            setHSVPixelColor(frameDBSCAN,x2,y2,dbscanLabel);
            cvtColor(frameDBSCAN,tempMat3,CV_HSV2BGR);
            imshow( "DBSCAN", tempMat3); // Show our image inside it.      
            
            waitKey(1);

        }

        waitKey(1);
        if(fileStream.fail())
        {
            std::cerr << "End of file."<<trkIdx<< std::endl;
        }
    }

    //imwrite("DTM.jpg",tempMat1);// it will store the image in name "result.jpg"
    //imwrite("meanshift89.jpg",tempMat2);// it will store the image in name "result.jpg"
    imwrite("DBSCAN9.jpg",tempMat3);// it will store the image in name "result.jpg"
    waitKey(0);
}


int showTrkClusterResults(char *pFilepath, Mat&clusterFrame,  int state)
{
    char filename[200];
    sprintf(filename, pFilepath);
    int length = strlen(filename);
    Mat tempMat;
    int count = 0;
    Mat endPtFrame = clusterFrame.clone();
    Mat origTrkFrame = clusterFrame.clone();
    cvtColor(endPtFrame,endPtFrame,CV_HSV2BGR);
    //cvtColor(origTrkFrame,origTrkFrame,CV_HSV2BGR);
    for (int trkIdx = 0; trkIdx < MAX_NUM_OBS; trkIdx++)
    {
        sprintf(filename + length, "%d.txt", trkIdx);

        std::ifstream fileStream(filename);
        int x1, y1, t1, x2, y2, t2;
        if(!fileStream.good())
        {
            std::cerr << "Could not open file."<<trkIdx << std::endl;
            continue;
        }
        if (!(fileStream >> x1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        if (!(fileStream >> y1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        if (!(fileStream >> t1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }        
        std::cout << x1 << ",";
        std::cout << y1 << std::endl;

        TrackData &obs = gTrkObservations.at(count);
        //setPixelColor(endPtFrame,x1,y1,2);
        //circle(endPtFrame, Point(x1, y1), 0.5, Scalar(255, 0, 0), -1);
        //circle(origTrkFrame, Point(x1, y1), 0.5, Scalar(255, 0, 0), -1);
        setHSVPixelColor(clusterFrame,x1,y1,obs.Label);
        cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
        //imshow( "clustered", tempMat); // Show our image inside it.
        //imshow( "endpt", endPtFrame); // Show our image inside it.
        x2 = x1;
        y2 = y1;
        int col1, col2, col3;
        int time = 0;
        for(time = 0; fileStream >> col1 && fileStream >> col2 && fileStream >> col3; time++)
        {
            x2 = col1;
            y2 = col2;
            t2 = col3;
            //std::cout << x2 << ",";
            //std::cout << y2 << std::endl;
            //setPixelColor(clusterFrame,x2,y2,obs.Label);
            //circle(origTrkFrame, Point(x2, y2), 0.5, Scalar(255, 0, 0), -1);
            setHSVPixelColor(clusterFrame,x2,y2,obs.Label);
            cvtColor(clusterFrame,tempMat,CV_HSV2BGR);
            //imshow( "clustered", tempMat); // Show our image inside it.
            //waitKey(1);

        }
        //setPixelColor(endPtFrame,x2,y2,9);
        circle(endPtFrame, Point(x2, y2), 0.5, Scalar(0, 255, 0), -1);
        //imshow( "endpt", endPtFrame); // Show our image inside it.        
        //imshow( "origTrkFrame", origTrkFrame); // Show our image inside it.     
        count++;
        waitKey(1);
        if(fileStream.fail())
        {
            std::cerr << "End of file."<<trkIdx<< std::endl;
        }
    }
    stringstream ss;
    ss <<"./results/"<<"Cluster_state_"<<state;
    string motString = ss.str();    
    imwrite(motString+".jpg",tempMat);// it will store the image in name "result.jpg"
    imwrite(motString+"endpt.jpg",endPtFrame);// it will store the image in name "result.jpg"
    //imwrite("trackOrig.jpg",origTrkFrame);// it will store the image in name "result.jpg"
    waitKey(0);
}

int createTrkObservationFile(char *pFilepath, char* trkfilename, Mat frame)
{
    char filename[200];
    int count = 0;
    if (std::ifstream(trkfilename))
    {
         std::cout<<trkfilename<< ", File already exists" << std::endl;
         return 0;
    }

    std::ofstream fileOutStream;
    fileOutStream.open (trkfilename);
    
    sprintf(filename, pFilepath);
    int length = strlen(filename);
    for (int trkIdx = 0; trkIdx < MAX_NUM_OBS;trkIdx++)
    {
        sprintf(filename + length, "%d.txt", trkIdx);
        
        std::ifstream fileStream(filename);
        int x1, y1, t1, x2, y2, t2;
        if(!fileStream.good())
        {
            std::cerr << "Could not open file."<<trkIdx << std::endl;
            continue;
        }
        if (!(fileStream >> x1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        if (!(fileStream >> y1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }
        if (!(fileStream >> t1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
        }        
        std::cout << x1 << ","<< y1<<", "<<t1<< std::endl;

        circle(frame, Point(x1, y1), 0.7, Scalar(0, 0, 255), -1);
        //imshow( "window", frame ); // Show our image inside it.
        x2 = x1;
        y2 = y1;
        int col1, col2, col3;
        int time = 0;
        for(time = 0; fileStream >> col1 && fileStream >> col2 && fileStream >> col3; time++)
        {
            x2 = col1;
            y2 = col2;
            t2 = col3;
            //std::cout << x2 << ",";
            //std::cout << y2 << std::endl;
            circle(frame, Point(x2, y2), 0.7, Scalar(255, 0, 0), -1);
            //imshow( "window", frame); // Show our image inside it.
            //waitKey(1);

        }
        circle(frame, Point(x1, y1), 0.9, Scalar(0, 0, 255), -1);
        circle(frame, Point(x2, y2), 0.9, Scalar(0, 255, 0), -1);
        fileOutStream<<x1<<"\t"<<y1<<"\t"<<x2<<"\t"<<y2<<"\t"<<time<<"\t"<< trkIdx<<"\t"<< t1<<"\t"<< t2<<endl;
        count++;
        waitKey(1);
        if(fileStream.fail())
        {
            std::cerr << "End of file."<<trkIdx<< std::endl;
        }
    }
    imwrite("originalTracks.jpg", frame);
    fileOutStream.close();

}

///trackdata/Dataset/MIT/original_trajectory/
int main(){
    double alpha = 0.5; double beta; double input;

    //initGradColor();
    initTrkObservations(MAX_NUM_OBS);
    initTrkCluster();

    logTempDoc.open ("logTempDoc.txt");
    logTempDoc<<"Temporal Document Preparation Log."<<endl;
    logTempDoc<<"BETA:"<<DELTA_EXPONENT<<endl;
    logTempDoc<<"BETA_MD:"<<DELTA_EXPONENT_MD<<endl;
    logTempDoc<<"GIBBS_SAMPLING_NO"<<GIBBS_SAMPLING_NO<<endl;
    logTempDoc<<"NO_SOURCE_FEATURES:"<<NO_SOURCE_FEATURES<<endl;
    logTempDoc<<"NO_DESTINATION_FEATURES:"<<NO_DESTINATION_FEATURES<<endl;
    logTempDoc<<"NO_TIME_FEATURES:"<<NO_TIME_FEATURES<<endl;
 
    Mat frame = imread("../trackdata/Dataset/QMUL/qmul_bg.png", CV_LOAD_IMAGE_COLOR);
    /*Mat frame = imread("/home/sk47/workspaceAnomaly/QMUL_TrackCreation/TUIC/RUPALI.jpg");*/


    if(! frame.data )  // Check for invalid input
    {
        cout<<"Empty image"<<endl;
        return -1;
    }
    // get the video parameters
    //int frameNumbers = (int) cap.get(CV_CAP_PROP_FRAME_COUNT);
    //int fps = (int) cap.get(CV_CAP_PROP_FPS);
    //cap >> frame;
    if (frame.empty())
    {
        cout<<"Empty video"<<endl;
        return -1;
    }
    cout<<"Original height X width = "<<frame.rows<<"X"<<frame.cols<<endl;
    Mat clusterFrame = frame.clone();
    

    Mat frameTrk;
    cvtColor(frame,frameTrk,CV_BGR2HSV);

    //Mat mask;
    //inRange(frameTrk, Scalar(0,0,0), Scalar(100, 255, 255), mask);
    //frameTrk.setTo(Scalar(0,0,0), mask);
    //frameTrk.setTo(Scalar(0,0,0));
    
    //DISPLAY image
    namedWindow( "window", CV_WINDOW_AUTOSIZE ); // Create a window for display.
    imshow( "window", frame ); // Show our image inside it.
    char* trkfilename = "track_obs_gKLT_DTM_noiseless_GT_50.txt";
    
    char *pFilepath = "/home/sk47/workspaceAnomaly/QMUL_TrackCreation/gKLT/gKLT_GT_50_ALL_REINDEXED_NOISELESS/";
    /*char *pFilepath = "/home/sk47/workspaceAnomaly/QMUL_TrackCreation/TUIC/rupali_trajectories_reindexed/";*/

    
    createTrkObservationFile(pFilepath, trkfilename, frame);

    initializeTrkObservation(trkfilename);
 
    
    //SAVE image
    //imwrite("result.jpg",frame);// it will store the image in name "result.jpg"
    //cout<<"Num Obs:"<<gTrkObservations.size()<<endl;

    logTempDoc<<"Iteration\t"<<"CumDistance"<<endl;
    for (int itr = 0; itr < GIBBS_SAMPLING_NO; itr++)
    {
        clusterTrkGibbs(0, pFilepath, frameTrk, itr);
        int max = (MAX_NUM_MOTIFS - gMotifMgr.count);
        //logTempDoc<<"Iteration:"<<itr<<",Num Clusters:"<<max<<endl;
        //displayTrkClustersStat(itr); 
        //cout<<"Iteration:"<<itr<<endl;
        //gDistanceSwitch = (gDistanceSwitch + 1)%2;
        //cv::waitKey();
    }
    //displayTrkObservationStat();
    //displayTrkClustersStat();
    
    //showTrkClusterResultsMotifWise(pFilepath, frameTrk);
    //testColorGradient(frameTrk);
    //showTrkClusterComparison(pFilepath, frameTrk);
#if 0

    cout<<"Num Clusters:"<<(MAX_NUM_MOTIFS - gMotifMgr.count)<<endl;

    /// Create Windows
    namedWindow("Linear Blend", 1);
    
    beta = ( 1.0 - alpha );
    Mat dst;
    addWeighted( frameTrk, alpha, frame, beta, 0.0, dst);
    
    imshow( "Linear Blend", dst );
    imwrite("trackblend.jpg",dst);// it will store the image in name "result.jpg"

    waitKey(0);
#endif
    cout<<"I am done"<<endl;
    logTempDoc.close();
}

//Initially all the points will be clusters themselves
int initTrkCluster()
{
    initList(&gMotifMgr, MAX_NUM_MOTIFS);   
    for (int i = 0; i < MAX_NUM_MOTIFS; i++)
    {
        TrackDataCentroid ctd = defaultInitedTrkCtd();
        ctd.trkClusterMgr.pDataList = gTrkMgr.pDataList;           
        gTrkClusters.push_back(ctd);
    }
    gNxtFreeCltIdx = -1;

    return 0;
}

int initTrkObservations(unsigned short numObs)
{
    if (!gTrkObsData)
    {
        gTrkObsData = (TrackData *)malloc(numObs*sizeof(TrackData));
        if (!gTrkObsData)
        {
            cout<<"Allocation failed for gTrkObservations"<<endl;
            exit(0);
        }
    }
    
    initList(&gTrkMgr, numObs);  

    return 0;
}
int initializeTrkObservation(char * trkfilename)
{
    int x1;
    int y1;
    int x2;
    int y2;
    int time;
    int trkIdx;
    int t1;
    int t2;    
    std::ifstream fileStream(trkfilename);
    if(!fileStream.good())
    {
        std::cerr << "Could not open file:"<<trkfilename << std::endl;
        return -1;
    }  
    while (!fileStream.fail())
    {
        if (!(fileStream >> x1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }
        if (!(fileStream >> y1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }  
        if (!(fileStream >> x2))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }
        if (!(fileStream >> y2))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }   
        if (!(fileStream >> time))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }  
        if (!(fileStream >> trkIdx))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }    
        if (!(fileStream >> t1))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }    
        if (!(fileStream >> t2))
        {
            std::cerr << "Not enough entries in the file."<<trkIdx << std::endl;
            return -1;
        }            
        insertTrkObservation(x1, y1, x2, y2, time, trkIdx, t1, t2);
    }
}
int insertTrkObservation
(
    int x1,
    int y1,
    int x2,
    int y2,
    int time,
    int idx,
    unsigned int t1,
    unsigned int t2
)
{
    defaultSetTrkObs(x1, y1, x2, y2, time, idx, t1, t2, gTrkObsData[idx]);
    gTrkObservations.push_back(gTrkObsData[idx]);
}
TrackDataCentroid defaultInitedTrkCtd()
{
    TrackDataCentroid ctd = {Mat(1, TOT_FEATURES, CV_64F, Scalar::all(0)),
                            Mat(TOT_FEATURES, TOT_FEATURES, CV_64F, Scalar::all(0)),
                            0, //x1
                            0, //y1
                            0, //x2
                            0, //y2
                            0, // time
                            gTrkClusters.size(), //clusterLabel
                            0, // No of tracks
                            0,//maxUD
                            0,//maxMD
                            ALPHA,//alpha
                            0,
                            0,
                            {0}};
    return ctd;
}

void defaultSetTrkObs
(
    int x1, 
    int y1,
    int x2, 
    int y2, 
    int time, 
    int index, 
    unsigned int t1,
    unsigned int t2,
    TrackData &obs
)
{
    Mat test = Mat(1, TOT_FEATURES, CV_64F, Scalar::all(0));
    test.copyTo(obs.pointData);
    obs.x1 = x1;
    obs.y1 = y1;
    obs.x2 = x2;
    obs.y2 = y2;
    obs.time = time;
    obs.Label = INVALID_IDX;
    obs.trackIdx = index;
    obs.startTime = t1;
    obs.endTime = t2;
    int i = 0;
#if NO_DESTINATION_FEATURES
    obs.pointData.at<double>(0,i++) = x2;
    obs.pointData.at<double>(0,i++) = y2;
#endif    
#if NO_SOURCE_FEATURES
    obs.pointData.at<double>(0,i++) = x1;
    obs.pointData.at<double>(0,i++) = y1;
#endif 
#if NO_TIME_FEATURES
    obs.pointData.at<double>(0,i++) = time;
#endif

    return;
}


int clusterTrkGibbs
(
    int frameNo,
    char *pFilepath, 
    Mat&clusterFrame,
    int gibbsIter
)
{
    double probNewClust;
    double probExClust;
    double uclidDistance;
    double mahanDistance;
    unsigned int clusterIdx;
    unsigned int maxObs = gTrkObservations.size();
    int time = 0;
    int idx = 0; 
    int lastUnassigned = 0;
    int prevState = 0;
    int newState = 0;
    for (int time = 1; time < MAX_TIME; time++)//time
    {
        TrackData obs = gTrkObservations.at(idx);

        if (0 == time % MAX_WINDOW)
        {
            cout<<"Entering Plotting Stage"<<endl;
            //displayTrkClustersStat(newState);
            displayTrkObservationStat(newState);
            //showTrkClusterResultsMotifWise(pFilepath, clusterFrame, newState); 
            //showTrkClusterResults(pFilepath, clusterFrame, newState);
            prevState = newState;
            newState += 1; 
            cout<<"entered new state: Go for resampling for state:"<<newState<<endl;
            TrackData obsOld = gTrkObservations.at(lastUnassigned);
            int deadState = obsOld.startTime/MAX_WINDOW;
            while (deadState < prevState)
            {
                remTrkObsFromCluster(lastUnassigned, frameNo, gibbsIter);
                lastUnassigned++;
                TrackData obsOld = gTrkObservations.at(lastUnassigned);
                deadState = obsOld.startTime/MAX_WINDOW;
            }
            //displayTrkObservationStat(newState);
            //displayTrkClustersStat(newState);
            showTrkClusterResultsMotifWise(pFilepath, clusterFrame, newState); 
            //Resample? Let us see without it .Any ways should be done later.             
        }
        //cout<<"time"<<time<<endl;
        while (time == obs.startTime)
        {   
            cout<<"New Track :"<<idx<<" at:"<<time<<endl;
            probNewClust = probNewTrkCluster(idx);
            probExClust = probExTrkCluster(idx, &clusterIdx, &uclidDistance, &mahanDistance);
            //logTempDoc<<"Probab of Obs("<<obs.x<<","<<obs.y<<endl<<"), Prob(ExCluster)="<<probExClust<<", Prob(NewCluster)="<<probNewClust<<endl;
            if (probNewClust > probExClust)//Observation going to new cluster
            {
                //clusterIdx = getTrkCluster(frameNo);//get free cluster
                clusterIdx = getTrkClusterFromMgr();
                if (-1 == clusterIdx)
                {
                    cout<<"Cluster numbers exeeded the limit"<<endl;
                    exit(0);
                }
                setTrkClusterValue(idx, clusterIdx, frameNo);
            }
            else//Observation going to existing cluster
            {
                //logTempDoc<<"distance = "<<distance<<" of obs("<<obs.x<<","<<obs.y<<")to cluster = "<<clusterIdx<<endl;
                //Add obs to existing cluster
                addTrkObsToCluster(frameNo, idx, clusterIdx);
                TrackDataCentroid &ctd = gTrkClusters.at(clusterIdx);
                if (uclidDistance > ctd.maxUD)
                {
                    ctd.maxUD = uclidDistance;
                }
                if (mahanDistance > ctd.maxMD)
                {
                    ctd.maxMD = mahanDistance;
                }
            }
            idx++;
            obs = gTrkObservations.at(idx);
            cout<<"clustering over  for trajectory:"<<idx<<endl;
        }
        cout<<prevState<<":Clustering over for trajectories at :"<<time<<endl;
        //logTempDoc<<"AfterAssignframeNo:"<<frameNo<<", ObxIdx:"<<idx<<", dir:"<<obs.dir<<", prevDir:"<<obs.prevDir<<", clsLabel:"<<obs.Label<<endl;

    }

}



//Initially all the points will be clusters themselves
int remTrkObsFromCluster(unsigned int pixIdx, int frameNo, int gibbsIter)
{


    TrackData &obs = gTrkObservations.at(pixIdx);
    unsigned int clusterIdx = obs.Label;

    TrackDataCentroid &ctd = gTrkClusters.at(clusterIdx);


    //Update the parameters of the centroid
    if (ctd.noOfTrack > 1)
    {
        float curNuX1 = ctd.x1;//nu(n)
        float curNuY1 = ctd.y1;//nu(n)
        float curNuTime = ctd.time;//nu(n)
        float curNuX2 = ctd.x2;//nu(n)
        float curNuY2 = ctd.y2;//nu(n)

        ctd.x1 = (ctd.x1*ctd.noOfTrack - obs.x1)/(ctd.noOfTrack - 1);//nu(n)*n/(n-1) - x(n)/(n-1)
        ctd.y1 = (ctd.y1*ctd.noOfTrack - obs.y1)/(ctd.noOfTrack - 1);
        ctd.x2 = (ctd.x2*ctd.noOfTrack - obs.x2)/(ctd.noOfTrack - 1);
        ctd.y2 = (ctd.y2*ctd.noOfTrack - obs.y2)/(ctd.noOfTrack - 1);
        ctd.time = (ctd.time*ctd.noOfTrack - obs.time)/(ctd.noOfTrack - 1);

        //New Modification 3-5-2017
        ctd.pointCtd = (ctd.pointCtd*ctd.noOfTrack - obs.pointData) /(ctd.noOfTrack - 1);
        //New Modification 3-5-2017
        int offset;
#if 0
        offset = 0;
        //Update the featureMat
#if NO_DESTINATION_FEATURES 
        ctd.pointCtd.at<double>(0,offset++) = ctd.x2;
        ctd.pointCtd.at<double>(0,offset++) = ctd.y2;
#endif
#if NO_SOURCE_FEATURES 
        ctd.pointCtd.at<double>(0,offset++) = ctd.x1;
        ctd.pointCtd.at<double>(0,offset++) = ctd.y1;
#endif
#if NO_TIME_FEATURES        
        ctd.pointCtd.at<double>(0,offset++) = ctd.time;
#endif
#endif
        //New Modification 3-5-2017
        Mat nuN = Mat(1, TOT_FEATURES, CV_64F, Scalar::all(0));
        offset = 0;
#if NO_DESTINATION_FEATURES
        nuN.at<double>(0, offset++) = curNuX2;
        nuN.at<double>(0, offset++) = curNuY2;
#endif        
#if NO_SOURCE_FEATURES        
        nuN.at<double>(0, offset++) = curNuX1;
        nuN.at<double>(0, offset++) = curNuY1;
#endif
#if NO_TIME_FEATURES        
        nuN.at<double>(0, offset++) = curNuTime;  
#endif
        //s(n) = s(n-1) + [x(n) - nu(n-1)]*[x(n) - nu(n)];
        //s(n-1) =s(n) - [x(n) - nu(n-1)]*[x(n) - nu(n)];
        
        Mat var = ctd.cov.clone() * ctd.noOfTrack ; //s(n)
        
        var -= (obs.pointData - ctd.pointCtd).t()*(obs.pointData - nuN);
        var /= (ctd.noOfTrack - 1);
        var.copyTo(ctd.cov);
        //New Modification 3-5-2017

#if 0
        //Calculate variance ignoring cross variance.Considering only diagonal elements
        // var = s(n)/n
        ctd.cov *= ctd.noOfTrack;
        //s(n) = s(n-1) + [x(n) - nu(n-1)]*[x(n) - nu(n)];
        offset = 0;
#if NO_DESTINATION_FEATURES         
        ctd.cov.at<double>(offset, offset) -= (obs.x2 - ctd.x2)*(obs.x2 - curNuX2);
        offset++;
        ctd.cov.at<double>(offset, offset) -= (obs.y2 - ctd.y2)*(obs.y2 - curNuY2);
        offset++;
#endif
#if NO_SOURCE_FEATURES 
        ctd.cov.at<double>(offset, offset) -= (obs.x1 - ctd.x1)*(obs.x1 - curNuX1);
        offset++;
        ctd.cov.at<double>(offset, offset) -= (obs.y1 - ctd.y1)*(obs.y1 - curNuY1);
        offset++;
#endif
#if NO_TIME_FEATURES         
        ctd.cov.at<double>(offset, offset) -= (obs.time - ctd.time)*(obs.time- curNuTime);
#endif
        //Added on 3-5-2017
        for (int i = 0; i < TOT_FEATURES; i++)
        {
            for (int j = i+1; j < TOT_FEATURES; j++)
            {
                if (i != j)
                {
                    ctd.cov.at<double>(i, j) = sqrt(ctd.cov.at<double>(i, i) * ctd.cov.at<double>(j, j));
                    ctd.cov.at<double>(j, i) = ctd.cov.at<double>(i, j);
                }
            }        
        }
        //Added on 3-5-2017

        //ctd.cov.at<float>(2,2) -= (obs.dir- ctd.dir)*(obs.dir - ctd.dir);
        //ctd.cov.at<float>(3,3) -= (obs.mag- ctd.mag)*(obs.mag - ctd.mag);
        ctd.cov /= (ctd.noOfTrack- 1);
#endif

        ctd.noOfTrack--;

        //Update the parameters of the centroid
        obs.Label = INVALID_IDX;
        //To handle unassign step
        deleteData(&ctd.trkClusterMgr, obs.trackIdx);
        //To handle unassign step

    }
    else
    {
        ctd.noOfTrack--;

        //Update the parameters of the centroid
        obs.Label = INVALID_IDX; 
        //To handle unassign step
        deleteData(&ctd.trkClusterMgr, obs.trackIdx);
        //To handle unassign step
        
        putTrkClusterToMgr(clusterIdx);
#if 0        
        ctd.x1 = obs.x1;//nu(n)*n/(n-1) - x(n)/(n-1)
        ctd.y1 = obs.y1;
        ctd.x2 = obs.x2;
        ctd.y2 = obs.y2;
        ctd.time = obs.time;

        ctd.cov *= ctd.noOfTrack;
        //s(n) = s(n-1) + [x(n) - nu(n-1)]*[x(n) - nu(n)];

        int offset = 0;
        //Update the featureMat

#if NO_DESTINATION_FEATURES         
        ctd.pointCtd.at<double>(0,offset++) = ctd.x2;
        ctd.pointCtd.at<double>(0,offset++) = ctd.y2;
#endif
#if NO_SOURCE_FEATURES         
        ctd.pointCtd.at<double>(0,offset++) = ctd.x1;
        ctd.pointCtd.at<double>(0,offset++) = ctd.y1;
#endif
#if NO_TIME_FEATURES         
        ctd.pointCtd.at<double>(0,offset++) = ctd.time;
#endif
        ctd.cov.setTo(Scalar(0));
#if 0
        offset = 0;
#if NO_DESTINATION_FEATURES 
        ctd.cov.at<double>(offset, offset) = 0;
        offset++;
        ctd.cov.at<double>(offset, offset) = 0;
        offset++;
#endif
#if NO_SOURCE_FEATURES         
        ctd.cov.at<double>(offset, offset) = 0;
        offset++;
        ctd.cov.at<double>(offset, offset) = 0;
        offset++;
#endif
#if NO_TIME_FEATURES         
        ctd.cov.at<double>(offset, offset) = 0;
#endif
#endif
#endif
    }

    
    return 0;
}

//Probability of the pixel going to a new cluster
double probNewTrkCluster
(
    unsigned int pixIdx
)
{
    //Need to consider a likelihood function also
    // if no clusters nearby then probably a new cluster needs to be formed
    //double probNewCluster = DELTA /(NUM_OBS - 1 + DELTA);
    
    if (gDistanceSwitch)//Use MD
    {
        return DELTA_EXPONENT_MD;
    }
    else
    {
        return DELTA_EXPONENT;
    }
}


//finding the probability of pixel going to existing cluster
double probExTrkCluster
(
    unsigned int pixIdx,
    unsigned int *pClusterIdx,
    double *pUD,
    double *pMD
)
{
    double minUDist = 0;
    double minMDist = 0;
    double maxProb = MIN_PROB_EXP;
    unsigned int clusterIdx = INVALID_IDX;
    double ctdx;
    double ctdy;
    double regFactor, regFactor1, regFactor2;
    double regFactorMax, regFactor1Max, regFactor2Max;

    TrackData &obs = gTrkObservations.at(pixIdx);

    //Find the distance with each cluster and find the  Max probability Cluster
    unsigned int clSize = gTrkClusters.size();
    if (clSize <= 0)
    {
        *pUD = minUDist;
        *pMD = minMDist;
        *pClusterIdx = clusterIdx;
        return maxProb;
    }
    for (int idx = 0; idx < clSize; idx++)//Skip the background cluster
    {
        TrackDataCentroid &centroid = gTrkClusters.at(idx);

        //No Need to check against Ctd with 0 Observations
        if (centroid.noOfTrack <= 0)
        {
            continue;
        }

        //displayClusterData(centroid);
        double dist = norm(obs.pointData, centroid.pointCtd, NORM_L2);
        regFactor1 = (-dist*dist/(2*SIGMA*SIGMA));
        Mat expResult(1,1,CV_64F);
        expResult = ((obs.pointData - centroid.pointCtd)*centroid.cov.inv()*(obs.pointData - centroid.pointCtd).t());
        double expData = expResult.at<double>(0,0);

#if UD
        regFactor = -dist;
#elif MD
        regFactor = - sqrt(expData);
#else // should take hardcoded value hardcode should be 1 in this case
        regFactor = -0.5 *expData;
#endif

        if (gDistanceSwitch)//Use MD
        {
            regFactor = - sqrt(expData);
        }
        else//use UD
        {
            regFactor = -dist;
        }
        float currProb = log(centroid.noOfTrack) + regFactor;//centroid.noOfPix/(NUM_OBS - 1 + DELTA)* regFactor;

        if (maxProb < currProb)
        {
            minUDist = dist;
            minMDist = sqrt(expData);
            clusterIdx = idx;
            maxProb = currProb;
            regFactorMax = regFactor;
            regFactor1Max = regFactor1;
            regFactor2Max = regFactor2;
        }
    }

    *pClusterIdx = clusterIdx;
    *pUD= minUDist;
    *pMD= minMDist;

    //maxProb = maxProb;//normalise
    //logTempDoc<<"Dist, regFactor2, regFactor1, regFactor:"<<minDist*minDist<<", "<<regFactor2Max<<", "<<regFactor1Max<< ", " <<regFactorMax<<endl;
    //logTempDoc<<"Probab of Obs("<<obs.x<<","<<obs.y<<"), going to cluster:"<<clusterIdx<<"("<<ctdx<<","<<ctdy<<") is = "<<maxProb<<endl;
    //cout<<"Probab of Obs("<<obs.x<<","<<obs.y<<"), going to cluster:"<<clusterIdx<<"("<<ctdx<<","<<ctdy<<") is = "<<maxProb<<endl;

    return maxProb;// normalise
}

int addTrkObsToCluster
(
    int frameNo,
    unsigned int pixIdx,
    unsigned int clusterIdx
)
{
    TrackData &obs = gTrkObservations.at(pixIdx);
    int offset;
    if (obs.Label == clusterIdx)//Already in cluster?
    {
        logTempDoc<<pixIdx<<"th Observation already in Cluster:"<<clusterIdx<<endl;
        return 0;
    }

    TrackDataCentroid &ctd = gTrkClusters.at(clusterIdx);
    //Update Observation label
    obs.Label = clusterIdx;

    //Update the parameters of the centroid
    ctd.noOfTrack++;

    //Update the parameters of the centroid
    float prevNuX1 = ctd.x1;//nu(n-1)
    float prevNuY1 = ctd.y1;//nu(n-1)
    float prevNuTime = ctd.time;//nu(n-1)
    float prevNuX2 = ctd.x2;//nu(n-1)
    float prevNuY2 = ctd.y2;//nu(n-1)

    //Mat prevCtdPtData = ctd.pointCtd.clone();
    Mat prevCtdPtData = Mat(1, TOT_FEATURES, CV_64F, Scalar::all(0));
    offset = 0;
#if NO_DESTINATION_FEATURES      
    prevCtdPtData.at<double>(0, offset++) = prevNuX2;
    prevCtdPtData.at<double>(0, offset++) = prevNuY2;
#endif    
#if NO_SOURCE_FEATURES      
    prevCtdPtData.at<double>(0, offset++) = prevNuX1;
    prevCtdPtData.at<double>(0, offset++) = prevNuY1;
#endif     
#if NO_TIME_FEATURES      
    prevCtdPtData.at<double>(0, offset++) = prevNuTime;    
#endif 

    //nu(n) = nu(n-1) + [(x(n)-nu(n-1)]/n
    ctd.x1 = ctd.x1 + (obs.x1 - ctd.x1)/ctd.noOfTrack;    
    ctd.y1 = ctd.y1 + (obs.y1 - ctd.y1)/ctd.noOfTrack;
    ctd.x2 = ctd.x2 + (obs.x2 - ctd.x2)/ctd.noOfTrack;
    ctd.y2 = ctd.y2 + (obs.y2 - ctd.y2)/ctd.noOfTrack;
    ctd.time= ctd.time + (obs.time - ctd.time)/ctd.noOfTrack;

    //New Modification 3-5-2017
    ctd.pointCtd += (obs.pointData - ctd.pointCtd)/ctd.noOfTrack;
    //New Modification 3-5-2017
#if 0
    int offset = 0;
    //Update the featureMat
#if NO_DESTINATION_FEATURES     
    ctd.pointCtd.at<double>(0,offset++) = ctd.x2;
    ctd.pointCtd.at<double>(0,offset++) = ctd.y2;
#endif
#if NO_SOURCE_FEATURES 
    ctd.pointCtd.at<double>(0,offset++) = ctd.x1;
    ctd.pointCtd.at<double>(0,offset++) = ctd.y1;
#endif
#if NO_TIME_FEATURES     
    ctd.pointCtd.at<double>(0,offset++) = ctd.time;
#endif
#endif

    //New Modification 3-5-2017
    Mat var = ctd.cov.clone() * (ctd.noOfTrack - 1);
    var = var + (obs.pointData - prevCtdPtData).t()*(obs.pointData - ctd.pointCtd);
    var /= (double)ctd.noOfTrack;
    var.copyTo(ctd.cov);
    //New Modification 3-5-2017
#if 0
    //s(n) = s(n-1) + [x(n) - nu(n-1)]*[x(n) - nu(n)]; var_n = s(n)/n  -> s(n) = n * var_n 
    ctd.cov *= (ctd.noOfTrack - 1); //s(n-1)
    
    offset = 0;
    //Calculate variance ignoring cross variance.Considering only diagonal elements
#if NO_DESTINATION_FEATURES       
    ctd.cov.at<double>(offset, offset) += (obs.x2 - prevNuX2)*(obs.x2 - ctd.x2);
    offset++;
    ctd.cov.at<double>(offset, offset) += (obs.y2 - prevNuY2)*(obs.y2 - ctd.y2);
    offset++;
#endif
#if NO_SOURCE_FEATURES       
    ctd.cov.at<double>(offset, offset) += (obs.x1- prevNuX1)*(obs.x1- ctd.x1);
    offset++;
    ctd.cov.at<double>(offset, offset) += (obs.y1 - prevNuY1)*(obs.y1 - ctd.y1);
    offset++;
#endif
#if NO_TIME_FEATURES       
    ctd.cov.at<double>(offset, offset) += (obs.time- prevNuTime)*(obs.time - ctd.time);
#endif
    //Added on 3-5-2017
    for (int i = 0; i < TOT_FEATURES; i++)
    {
        for (int j = i+1; j < TOT_FEATURES; j++)
        {
            if (i != j)
            {
                ctd.cov.at<double>(i, j) = sqrt(ctd.cov.at<double>(i, i) * ctd.cov.at<double>(j, j));
                ctd.cov.at<double>(j, i) = ctd.cov.at<double>(i, j);
            }
        }        
    }
    //Added on 3-5-2017
    ctd.cov /= ctd.noOfTrack;
#endif
    ctd.timestamp = frameNo;
    insertData(&ctd.trkClusterMgr, obs.trackIdx);
    
    return 0;
}


int getTrkClusterFromMgr
(

)
{
    int idx;
    idx = getFreeData(&gMotifMgr);
    if (-1 != idx)
    {
        gNumTrkClusterAlloc++;
        int diff = gNumTrkClusterAlloc - gNumTrkClusterFreed;
        if ((diff) != (MAX_NUM_MOTIFS- gMotifMgr.count)) 
        {
            cout<<"Alloc:cluster List manager has issues, gNumTrkClusterAlloc, gNumTrkClusterFreed:"<<gNumTrkClusterAlloc<< ", gNumClusterFreed" <<gNumTrkClusterFreed<<", gClusterMgr.count"<<gTrkMgr.count<<endl;
            exit(0);
        }    
    }
    int count = 0;
    Data *pDataItem = gMotifMgr.pFirst;
    while (pDataItem)
    {
        count++;
        pDataItem = pDataItem->pNext;
    }
    if (count != gMotifMgr.count)
    {
        cout<<"Alloc:count:"<<count<<", gTrkMgr.count"<<gMotifMgr.count<<endl;
        exit(0);
    }

    return idx;    
}

int putTrkClusterToMgr
(
    int idx
)
{
    insertData(&gMotifMgr, idx);
    gNumTrkClusterFreed++;  
    int diff = gNumTrkClusterAlloc - gNumTrkClusterFreed;
    if ((diff) != (MAX_NUM_MOTIFS - gMotifMgr.count))
    {
        cout<<"Alloc:cluster List manager has issues, diff:"<<diff<<", gTrkMgr.count"<<gMotifMgr.count<<endl;
        exit(0);
    }  
    int count = 0;
    Data *pDataItem = gMotifMgr.pFirst;
    while (pDataItem)
    {
        count++;
        pDataItem = pDataItem->pNext;
    }
    if (count != gMotifMgr.count)
    {
        cout<<"Alloc:count:"<<count<<", gMotifMgr.count"<<gMotifMgr.count<<endl;
        exit(0);
    }
    return 0;
}

int setTrkClusterValue
(
    int trkIdx,
    int clsIdx,
    int frameNo
)
{
    TrackDataCentroid &ctd = gTrkClusters.at(clsIdx);
    TrackData &obs = gTrkObservations.at(trkIdx);

    ctd.x1 = obs.x1;
    ctd.y1 = obs.y1;
    ctd.x2 = obs.x2;
    ctd.y2 = obs.y2;
    ctd.time = obs.time;
    ctd.noOfTrack = 1;
    obs.Label = clsIdx;// do it outside?
    ctd.timestamp = frameNo;
    ctd.startTime = frameNo;

    int offset = 0;
    //Initialise Covariance matrix
#if NO_DESTINATION_FEATURES    
    ctd.cov.at<double>(offset,offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0,offset++) = obs.x2;

    ctd.cov.at<double>(offset,offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0,offset++) = obs.y2;
#endif
#if NO_SOURCE_FEATURES  
    ctd.cov.at<double>(offset, offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0,offset++) = obs.x1;
    ctd.cov.at<double>(offset, offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0,offset++) = obs.y1;
#endif
#if NO_TIME_FEATURES  
    ctd.cov.at<double>(offset,offset) = SIGMA*SIGMA;
    ctd.pointCtd.at<double>(0, offset++) = obs.time;
#endif    
    insertData(&ctd.trkClusterMgr, obs.trackIdx);

    return 0;
}

void displayTrkObservationStat(int state)
{
    //logTempDoc<<"--------------------------------------frameNo = "<<frameNo<<endl;
    //logTempDoc<<"frame\t"<<"#Cluster\t"<<"#Cluster(withDelay)"<<endl;
    logTempDoc<<"trackId"<<"\t"<<"x1"<<"\t"<<"y1"<<"\t"<<"x2"<<"\t"<<"y2"<<"\t"<<"sTime"<<"\t"<<"eTime"<<"\t"<<"time"<<"\t"<<"label"<<"\t"<<"state"<<endl;
    for (int idx = 0; idx < gTrkObservations.size(); idx++)
    {
        TrackData &obs = gTrkObservations.at(idx);

        logTempDoc<<obs.trackIdx<<"\t"<<obs.x1<<"\t"<<obs.y1<<"\t"<<obs.x2<<"\t"<<obs.y2<<"\t"<<obs.startTime<<"\t"<<obs.endTime<<"\t"<<obs.time<<"\t"<<obs.Label<<"\t"<<state<<endl;


    }

}

void displayTrkClustersStat(int itr)
{
    //logTempDoc<<"--------------------------------------frameNo = "<<frameNo<<endl;
    //logTempDoc<<"frame\t"<<"#Cluster\t"<<"#Cluster(withDelay)"<<endl;
    double sum = 0;
    double dist;
    Mat origPt = Mat(1, TOT_FEATURES, CV_64F, Scalar::all(0));
    logTempDoc<<"label"<<"\t"<<"x1"<<"\t"<<"y1"<<"\t"<<"x2"<<"\t"<<"y2"<<"\t"<<"time"<<"\t"<<"#Tracks"<<"\t"<<"#Tracks"<<"\t"<<"MD"<<"\t"<<"UD"<<endl;
    for (int idx = 0; idx < gTrkClusters.size(); idx++)
    {
        TrackDataCentroid &ctd = gTrkClusters.at(idx);
        if (ctd.noOfTrack)
        {
            logTempDoc<<ctd.label<<"\t"<<ctd.x1<<"\t"<<ctd.y1<<"\t"<<ctd.x2<<"\t"<<ctd.y2<<"\t"<<ctd.time<<"\t"<<ctd.noOfTrack<<"\t"<<ctd.trkClusterMgr.count<<"\t"<<ctd.maxMD<<"\t"<<ctd.maxUD<<endl;
            //logTempDoc<<"Mean:"<<ctd.pointCtd<<endl;
            //logTempDoc<<"CovMatrix:"<<endl<<ctd.cov<<endl;
            dist = norm(origPt, ctd.pointCtd, NORM_L2);
            sum += dist;
            //cout<<origPt<<"-"<<ctd.pointCtd<<" = "<<dist<<endl;
        }

    }
    logTempDoc<<itr<<"\t"<<sum<<endl;
    
    
}
void setHSVPixelUseColorGradient(Mat &showFrame, 
                                        int x,  
                                        int y, 
                                        int time,
                                        int timeDur)
{
     //Vec3b color = showFrame.at<Vec3b>(Point(x, y));
     Vec3b& hsv = showFrame.at<Vec3b>(y, x);

     hsv[0] = ((float)time/(float)timeDur)*180;//hue
     hsv[1] = 255;//saturation
     hsv[2] = 255;//

     //showFrame.at<Vec3b>(x, y) = hsv;
}

void setHSVPixelColor(Mat &showFrame, int x, int y, int label)
{
     //Vec3b color = showFrame.at<Vec3b>(Point(x, y));
     Vec3b& hsv = showFrame.at<Vec3b>(y, x);

     hsv[0] = label*10;//hue
     hsv[1] = 255;
     hsv[2] = 255;

     //showFrame.at<Vec3b>(x, y) = hsv;
}

