#ifndef UTILITY_H
#define UTILITY_H


#include <stdlib.h>
#include <iostream>

using namespace std;

typedef struct _Data Data;

struct _Data
{
	Data *pPrev;
	unsigned int idx;
    Data *pNext;
};
typedef struct _ListMgr
{
    Data *pDataList;
    Data *pFirst;
    unsigned int count;//Count statistics
    Data *pLast;
}ListMgr;

int initList(ListMgr *pDataMgr, int maxCount);
int insertData(ListMgr *pDataMgr, int idx);
int initList(ListMgr *pFreeDataMgr, int maxCount);
int deleteData(ListMgr *pDataMgr, int idx);
int getFreeData(ListMgr *pDataMgr);

#endif//UTILITY_H
