#ifndef CONFIG_H
#define CONFIG_H

//end of Parameters to be used in Gibbs Sampling

#define MAX_TIME 89950//GT_50 QMUL gKLT this frame number corresponds to the starting frame of last trajectory

//#define MAX_TIME 42433 //RUPALI


#define MAX_WINDOW 15000 //Window duration for which state is assessed QMUL

//#define MAX_WINDOW 10000 //RUPALI



#define MAX_NUM_OBS 16817 //GT_50 QMUL

//#define MAX_NUM_OBS 3861 //RUPALI


#define INVALID_IDX 0xFFFFFFFF

#define GIBBS_SAMPLING_NO 1

#define MAX_NUM_MOTIFS 150

#define SIGMA_HARDCODE 0

// Only one of these should be enabled
#define UD 1
#define MD 0

#define SIGMA 0

#define DELTA_EXPONENT (-(35 - log(1))) //UD-virat_02 50-1350
#define DELTA_EXPONENT_MD (-(10 - log(1))) //UD-virat_02 50-1350

#define ALPHA (exp(DELTA_EXPONENT))

#define MIN_PROB_EXP (-DBL_MAX)

//Clustering Features to be used
#define NO_SOURCE_FEATURES 2 /*2 or 0*/  
#define NO_DESTINATION_FEATURES 0 /*2 or 0*/  
#define NO_TIME_FEATURES 0 /*1 or 0*/   

#define TOT_FEATURES (NO_DESTINATION_FEATURES + NO_SOURCE_FEATURES + NO_TIME_FEATURES)

//Clustering Features to be used


#endif //MOTIF_CONFIG_H

